import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .database import database as db

import numpy as np
import pandas as pd

def player_match_performance_trend_layout(football_app):

    team = "AFCU9-1"
    player_id = "72264"

    all_matches = db.all_match_data_per_team(team, player_id)
    all_matches_list = all_matches['matchId'].to_list()
    internal_parameters = ['exerciseLoad', 'maxVO2']
    external_parameters = ['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',\
                                            'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh']
    ball_parameters = ['touches', 'passes', 'shots', 'tackles']


    layout = html.Div(children=[
        html.Details([
            html.Summary(
                "Parameter Selection"),
            html.Div([
                html.Div([
                    html.H6("Time Range", style={
                        'textAlign': 'center'}),
                    dcc.RangeSlider(
                        id="time-range-player",
                        min=1,
                        max=10,
                        step=1,
                        value=[1, 10]
                    ),
                ], style={'display': 'inline-block', 'width': '49%'}),

                html.Div(
                    id='slider-output-player', style={'display': 'inline-block', 'width': '10%'}),
                html.Div([
                    html.H6("Select Match", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-select-player',
                        options=[
                            {'label': i, 'value': i} for i in all_matches_list],
                        value=all_matches_list[0]
                    ),
                ], style={'display': 'inline-block', 'width': '40%'}),

            ]),
            html.Div([
                html.Div([
                    html.H6("Select Internal Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="internal-personal-player",
                        options=[
                            {'label': i, 'value': i} for i in internal_parameters],
                        value='exerciseLoad',
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
                html.Div([
                    html.H6("Select External Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="external-personal-player",
                        options=[
                            {'label': i, 'value': i} for i in external_parameters],
                        value='imaAccHigh',
                        multi=True
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
                html.Div([
                    html.H6("Select Ball Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="ball-personal-player",
                        options=[
                            {'label': i, 'value': i} for i in ball_parameters],
                        value='passes',
                        multi=True
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
            ]),
        ]),

        html.Div(id='match-bar-chart-player', children=[
        ], style={'width': '39%', 'display': 'inline-block'}),

        html.Div(id='development-trend-player', children=[
        ], style={'width': '59%', 'display': 'inline-block'}),
    ])

    # initiate the callbacks
    init_player_match_performance_trend_callbacks(football_app)

    return layout


#######################################

################ CALLBACKS #############

########################################

def init_player_match_performance_trend_callbacks(football_app):
    team = "AFCU9-1"
    player_id = "72264"

    all_matches = db.all_match_data_per_team(team, player_id)
    # update chart for performance trend on match select
    @football_app.callback(
        Output('match-bar-chart-player', 'children'),
        [Input('match-select-player', 'value'),
        Input('external-personal-player', 'value'),
        Input('internal-personal-player', 'value'),
        Input('ball-personal-player', 'value')]
    )
    def update_match_bar_chart(matchId, external, internal, ball):
        # if external, internal, ball are just one element than it is a string and not a list
        if isinstance(internal, str):
            internal_params = [internal]
        else:
            internal_params = internal
        
        if isinstance(external, str):
            external_params = [external]
        else:
            external_params = external

        if isinstance(ball, str):
            ball_params = [ball]
        else:
            ball_params = ball

        # get data from all_matches, this will be changed when averages are already in database
        # this will be data for that one selected game
        match_data = all_matches[all_matches['matchId']==matchId]

        # # external
        # external_data = match_data[external_params]

        # # internal
        # internal_data = match_data[internal_params]

        # # ball
        # ball_data = match_data[ball_params]

        parameter_list = [internal_params, external_params, ball_params]
        #parameter_labels = ["Internal", "External", "Ball"]

        # get bar chart, one for each category
        children_bar = []

        # # external chart
        # fig_external = go.Figure()

        # # add player trace
        # fig.add_trace(
        #     go.Bar(
        #         x=external_params, y=match_data[match_data['playerId']==player_id], name='You'
        #     )
        # )
        for l in parameter_list:
            temp_params = l.copy()
            temp_params.append('playerId')
            plot_df = match_data[temp_params]
            player_df = plot_df[plot_df['playerId']==player_id]
            player_df.drop(columns=['playerId'], inplace=True)
            #print(player_df)
            player_data = player_df.values.flatten()
            #print(player_data)
            mean_df = plot_df[plot_df['playerId']=='mean']
            mean_df.drop(columns=['playerId'], inplace=True)
            mean_data = mean_df.values.flatten()
            #print(mean_df)
            temp_params.remove('playerId')

            fig = go.Figure()

            # add mean trace
            fig.add_trace(
                go.Bar(
                    x=temp_params, y=mean_data, name='Team Average', marker_color='blue'
                )
            )

            # add player trace
            fig.add_trace(
                go.Bar(
                    x=temp_params, y=player_data, name='You', marker_color='orange', width=0.6,
                )
            )

            # layout
            fig.update_layout(
                height=300,
                template='seaborn',
                hovermode='x',
                barmode='overlay',
                showlegend=False,
                margin=dict(t=20, b=20, r=0),
            )

            chart_bar = dcc.Graph(
                figure=fig
            )

            children_bar.append(chart_bar)

        return children_bar

    @football_app.callback(
        Output('development-trend-player', 'children'),
        [Input('match-select-player', 'value'),
        Input('external-personal-player', 'value'),
        Input('internal-personal-player', 'value'),
        Input('ball-personal-player', 'value')]
    )
    def update_development_trend_player(selected_match, external, internal, ball):
        # if external, internal, ball are just one element than it is a string and not a list
        if isinstance(internal, str):
            internal_params = [internal]
        else:
            internal_params = internal
        
        if isinstance(external, str):
            external_params = [external]
        else:
            external_params = external

        if isinstance(ball, str):
            ball_params = [ball]
        else:
            ball_params = ball


        parameter_list = [internal_params, external_params, ball_params]
        #parameter_labels = ["Internal", "External", "Ball"]

        match_data = all_matches[all_matches['playerId']==player_id]
        matches = match_data['matchId'].tolist()

        children_trend = []

        for p in parameter_list:
            plot_df = match_data[p]
            fig = go.Figure()

            for param in p:
                fig.add_trace(
                    go.Scatter(
                        x=matches, y=plot_df[param], mode='lines+markers', name=param
                    )
                )

                # vertical line marker for selected match
                fig.add_shape(
                # Line Vertical
                    dict(
                        type="line",
                        xref="x",
                        yref="y",
                        x0=selected_match,
                        y0=0,
                        x1=selected_match,
                        y1=plot_df[param].max(),
                        line=dict(
                            color="Black",
                            width=3,
                            dash="dot",
                        )
                    )
                )
            
                

            fig.update_layout(
                legend=dict(x=0.5, y=1),
                legend_orientation="h",
                height=300,
                #width=600,
                # template='seaborn',
                # hovermode='x',
                showlegend=False,
                margin=dict(t=20, b=20, r=0),
                hovermode='x unified',
                template='plotly_white',
            )

            chart_trend = dcc.Graph(
                figure=fig,
            )
            
            children_trend.append(chart_trend)


        return children_trend
        
