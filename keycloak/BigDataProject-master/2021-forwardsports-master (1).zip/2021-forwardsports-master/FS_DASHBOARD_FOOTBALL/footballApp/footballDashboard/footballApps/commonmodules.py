import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

def get_header():
    header = html.Div([
        html.Div([
            html.H1('Forward Football Dashboard')
        ], style={"textAlign": "center"})      
    ])
    return header

def get_menu():
    menu = html.Div([
        dcc.Link('Home', href='/footballDashApp/'),
        dcc.Link('Club', href='/footballDashApp/club'),
        dcc.Link('Coach', href='/footballDashApp/coach'),
        dcc.Link('Player', href='/footballDashApp/player'),
    ], style={"textAlign": "center"})
    return menu    
