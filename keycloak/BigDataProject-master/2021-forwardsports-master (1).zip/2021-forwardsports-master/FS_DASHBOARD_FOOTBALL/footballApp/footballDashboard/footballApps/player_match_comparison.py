import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .database import database as db

import numpy as np
import pandas as pd


def player_match_comparison_layout(football_app):

    team = "AFCU9-1"
    player_id = "72264"

    all_matches = db.all_match_data_per_team(team, player_id)
    all_matches_list = all_matches['matchId'].to_list()
    internal_parameters = ['exerciseLoad', 'maxVO2']
    external_parameters = ['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',\
                                            'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh']
    ball_parameters = ['touches', 'passes', 'shots', 'tackles']

    layout = html.Div(children=[
        html.Details([
            html.Summary(
                "Parameter Selection"),
            html.Div([
                html.Div([
                    html.H6("Select Internal Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="internal-comparison-player",
                        options=[
                            {'label': i, 'value': i} for i in internal_parameters],
                        value='exerciseLoad',
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
                html.Div([
                    html.H6("Select External Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="external-comparison-player",
                        options=[
                            {'label': i, 'value': i} for i in external_parameters],
                        value='imaAccHigh',
                        multi=True
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
                html.Div([
                    html.H6("Select Ball Parameter", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id="ball-comparison-player",
                        options=[
                            {'label': i, 'value': i} for i in ball_parameters],
                        value='passes',
                        multi=True
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
            ]),
            html.Div([
                html.H6("Select Match 1", style={
                    'textAlign': 'center'}),
                dcc.Dropdown(
                    id='match-select-1-player',
                    options=[
                        {'label': i, 'value': i} for i in all_matches_list],
                    value=all_matches_list[0]
                ),
            ], style={'width': '49%', 'display': 'inline-block'}),
            html.Div([
                html.H6("Select Match 2", style={
                    'textAlign': 'center'}),
                dcc.Dropdown(
                    id='match-select-2-player',
                    options=[
                        {'label': i, 'value': i} for i in all_matches_list],
                    value=all_matches_list[1]
                ),
            ], style={'width': '49%', 'display': 'inline-block'}),
        ]),
        html.Div(id='score-match-select'),
        dcc.Graph(
            id='match-select-chart',
        ),
    ])

    # initiate callbacks
    init_player_match_comparison_callbacks(football_app)

    return layout

#######################################

################ CALLBACKS #############

########################################

def init_player_match_comparison_callbacks(football_app):

    team = "AFCU9-1"
    player_id = "72264"
    all_matches = db.all_match_data_per_team(team, player_id)

    @football_app.callback(
        [Output("match-select-chart", 'figure'),
        Output("score-match-select", 'children')],
        [Input("match-select-1-player", 'value'),
        Input("match-select-2-player", 'value'),
        Input('internal-comparison-player', 'value'),
        Input('external-comparison-player', 'value'),
        Input('ball-comparison-player', 'value')]
    )
    def update_match_select_chart(match1, match2, internal, external, ball):

        # get the game scores
        score1 = db.get_match_score(match1)
        score2 = db.get_match_score(match2)

        score = html.Div(children=[
                    html.Div(score1, style={'display': 'inline-block', 'width':'49%', 'textAlign': 'center'}),
                    html.Div(score2, style={'display': 'inline-block', 'width':'49%', 'textAlign': 'center'})
                ], style={"margin-bottom": "5px"})

        ## make sure that it is always a list when selection changes from one to mult ##
        if isinstance(internal, str):
            internal_params = [internal]
        else:
            internal_params = internal
        
        if isinstance(external, str):
            external_params = [external]
        else:
            external_params = external

        if isinstance(ball, str):
            ball_params = [ball]
        else:
            ball_params = ball

        #matches = [match1, match2]
        player_data = all_matches[all_matches['playerId'] == player_id]
        player_data.fillna(0, inplace=True)
        mean_data = all_matches[all_matches['playerId'] == 'mean']
        mean_data.fillna(0, inplace=True)

        player_data_match1 = player_data[player_data['matchId'] == match1]
        player_data_match2 = player_data[player_data['matchId'] == match2]

        mean_data_match1 = mean_data[mean_data['matchId'] == match1]
        mean_data_match2 = mean_data[mean_data['matchId'] == match2]

        internal_mean_match1 = pd.DataFrame(mean_data_match1[internal_params].transpose())
        internal_player_match1 = pd.DataFrame(player_data_match1[internal_params].transpose())
        internal_mean_match2 = pd.DataFrame(mean_data_match2[internal_params].transpose())
        internal_player_match2 = pd.DataFrame(player_data_match2[internal_params].transpose())

        external_mean_match1 = pd.DataFrame(mean_data_match1[external_params].transpose())
        external_player_match1 = pd.DataFrame(player_data_match1[external_params].transpose())
        external_mean_match2 = pd.DataFrame(mean_data_match2[external_params].transpose())
        external_player_match2 = pd.DataFrame(player_data_match2[external_params].transpose())

        ball_mean_match1 = pd.DataFrame(mean_data_match1[ball_params].transpose())
        ball_player_match1 = pd.DataFrame(player_data_match1[ball_params].transpose())
        ball_mean_match2 = pd.DataFrame(mean_data_match2[ball_params].transpose())
        ball_player_match2 = pd.DataFrame(player_data_match2[ball_params].transpose())

        # num_internal_params = len(internal_params)
        # num_external_params = len(external_params)
        # num_ball_params = len(ball_params)
        fig = make_subplots(
            rows=3, cols=2,
            specs=[[{}, {}], [{}, {}], [{}, {}]],
            subplot_titles=("Internal Match 1", "Internal Match 2", "External Match 1", "External Match 2", "Ball Match 1", "Ball Match 2", ),
            horizontal_spacing = 0.05, vertical_spacing = 0.15, shared_yaxes=True)

        ### Plots First Game ###
        # internal #
        fig.add_trace(
            go.Bar(x=internal_params, y=internal_mean_match1.iloc[:,0], marker_color='blue', name='Mean'),
            row=1, col=1,
        )
        fig.add_trace(
            go.Bar(x=internal_params, y=internal_player_match1.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=1, col=1,
        )
        # external #
        fig.add_trace(
            go.Bar(x=external_params, y=external_mean_match1.iloc[:,0], marker_color='blue', name='Mean'),
            row=2, col=1,
        )
        fig.add_trace(
            go.Bar(x=external_params, y=external_player_match1.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=2, col=1,
        )
        # ball #
        fig.add_trace(
            go.Bar(x=ball_params, y=ball_mean_match1.iloc[:,0], marker_color='blue', name='Mean'),
            row=3, col=1,
        )
        fig.add_trace(
            go.Bar(x=ball_params, y=ball_player_match1.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=3, col=1,
        )

        ### Plots Second Game ###
        # internal #
        fig.add_trace(
            go.Bar(x=internal_params, y=internal_mean_match2.iloc[:,0], marker_color='blue', name='Mean'),
            row=1, col=2,
        )
        fig.add_trace(
            go.Bar(x=internal_params, y=internal_player_match2.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=1, col=2,
        )
        # external #
        fig.add_trace(
            go.Bar(x=external_params, y=external_mean_match2.iloc[:,0], marker_color='blue', name='Mean'),
            row=2, col=2,
        )
        fig.add_trace(
            go.Bar(x=external_params, y=external_player_match2.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=2, col=2,
        )
        # ball #
        fig.add_trace(
            go.Bar(x=ball_params, y=ball_mean_match2.iloc[:,0], marker_color='blue', name='Mean'),
            row=3, col=2,
        )
        fig.add_trace(
            go.Bar(x=ball_params, y=ball_player_match2.iloc[:,0], marker_color='orange', name='You', width=0.6),
            row=3, col=2,
        )

        fig.update_layout(height=800, template='seaborn', showlegend=False, hovermode='x', barmode='overlay')

        return fig, score

