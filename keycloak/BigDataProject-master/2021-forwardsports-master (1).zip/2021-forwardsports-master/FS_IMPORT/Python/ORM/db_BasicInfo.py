from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Float, func
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import relationship, backref

from Python.ORM.base import Base


class BasicMatch(Base):
    __abstract__ = True

    Match_id = Column(String(255), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Date = Column(DateTime, nullable=False)
    Opponents = Column(String(255))
    Exp_team = Column(String(255))
    Team_id = Column(String(255), primary_key=True)
    Time = Column(String(255))
    Duration = Column(String(255))
    N_players = Column(String(255))

    def __repr__(self):
        return "<BasicMatch(File='%s', Match id='%s', Team Exported id='%s')>" % (
            self.Extracted_File, self.Match_id, self.Team_id)


class MatchID(object):
    @declared_attr
    def match_id(self):
        match_id = Column("Match_id", String(255),
                          ForeignKey('basic_match.Match_id',
                                     ondelete="cascade", onupdate="cascade"))
        return match_id

    @declared_attr
    def match(self):
        match = relationship("BasicMatch", backref=backref("basic_match"),
                             foreign_keys=[self.match_id])
        return match


class BasicPlayers(MatchID, Base):
    __abstract__ = True

    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Team_id = Column(Integer, primary_key=True)
    Player_id = Column(Integer, primary_key=True)
    Name = Column(String(25))
    Gender = Column(String(10))
    Birthday = Column(DateTime)
    Weight = Column(Float)
    Height = Column(Float)
    Position = Column(String(255))
    N_shirt = Column(Integer)
    Sub_on = Column(String(255))
    Sub_off = Column(String(255))
    Time_played = Column(Integer)
    HHR_Max = Column(Integer)
    HR_Max = Column(Integer)
    HR_Min = Column(Integer)
    HR_Avg = Column(Integer)
    Rate_0_50 = Column(Integer)
    Rate_50_60 = Column(Integer)
    Rate_60_70 = Column(Integer)
    Rate_70_80 = Column(Integer)
    Rate_80_90 = Column(Integer)
    Rate_90_100 = Column(Integer)
    Time_Ratio_0_50 = Column(String(255))
    Time_Ratio_50_60 = Column(String(255))
    Time_Ratio_60_70 = Column(String(255))
    Time_Ratio_70_80 = Column(String(255))
    Time_Ratio_80_90 = Column(String(255))
    Time_Ratio_90_100 = Column(String(255))
    Physical_Load = Column(Float)
    Intensity = Column(Float)
    VO2_Max = Column(Float)
    Calories = Column(Integer)
    Speed_Max = Column(Float)
    Dribble_Speed_Max = Column(Float)
    Distance = Column(Float)
    Distance_perMin = Column(Float)
    Walk_Distance = Column(Float)
    Jog_Distance = Column(Float)
    Low_Running_Distance = Column(Float)
    Medium_Running_Distance = Column(Float)
    High_Running_Distance = Column(Float)
    Sprint_Distance = Column(Float)
    High_Runs = Column(Integer)
    Sprints = Column(Integer)
    Run_Avg = Column(Float)
    Receives = Column(Integer)
    Passes = Column(Integer)
    Passes_Completed = Column(Integer)
    Passes_Completed_Perc = Column(String(255))
    Passes_Forward = Column(Integer)
    Passes_Completed_Forward = Column(Integer)
    Passes_Completed_Forward_Perc = Column(String(255))
    Passes_Forward_Perc = Column(String(255))
    Interceptions = Column(Integer)

    def __repr__(self):
        return "<BasicPlayers(File='%s', Match id='%s', Team Exported id='%s', Player id='%s')>" % (
            self.Extracted_File, self.Match_id, self.Team_id, self.Player_id)
