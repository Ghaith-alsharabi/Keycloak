from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Float, func
from sqlalchemy.orm import relationship, backref
from sqlalchemy.ext.declarative import declared_attr
from Python.ORM.base import Base


class TrainInfo(Base):
    __abstract__ = True

    Train_id = Column(String(255), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Time_begin = Column(String(255))
    Time_end = Column(String(255))
    Time = Column(String(255))
    Court_Length = Column(Float)
    Court_Width = Column(Float)
    Anchor_Mode = Column(String(10))
    Ball_Mode = Column(String(10))
    App_Version = Column(String(10))
    Algorithm_Version = Column(Float)
    Log_Version = Column(String(10))


class TrainId(object):
    @declared_attr
    def train_id(self):
        train_id = Column("Train_id", String(255),
                          ForeignKey('train_info.Train_id', name='%s_related_train_id' % self.__tablename__,
                                     ondelete="cascade", onupdate="cascade"), primary_key=True)
        return train_id

    @declared_attr
    def train(self):
        train = relationship("TrainInfo", backref=backref("train_info"), foreign_keys=[self.train_id])
        return train


class TrainTeam(TrainId, Base):
    __abstract__ = True

    Team_id = Column(String(255), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    team_Name = Column(String(255), nullable=False)


class TrainPlayers(TrainId, Base):
    __abstract__ = True

    Player_id = Column(Integer, primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Name = Column(String(255), nullable=False)
    Number = Column(Integer)
    Height = Column(Integer)
    Weight = Column(Integer)
    HR_base = Column(Integer)
    HHR_Max = Column(Integer)


class PlayerId(object):
    @declared_attr
    def player_id(self):
        player_id = Column("Player_id", Integer,
                           ForeignKey('train_players.Player_id', name='%s_related_player_id' % self.__tablename__,
                                      ondelete="cascade", onupdate="cascade"),
                           primary_key=True)
        return player_id

    @declared_attr
    def player(self):
        player = relationship("TrainPlayers", backref=backref("train_players"), foreign_keys=[self.player_id])
        return player


class TrainPhysical(TrainId, PlayerId, Base):
    __abstract__ = True

    id = Column(String(2), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Name = Column(String(255), nullable=False)
    Duration = Column(Integer)
    Distance_Covered = Column(Float)
    High_Speed_Distance = Column(Float)
    Sprint_Speed_Distance = Column(Float)
    Calories = Column(Float)
    Exercise_Load = Column(Float)
    HR_Max = Column(Integer)
    Speed_Max = Column(Float)
    VO2_Max = Column(Integer)
    Acc_Low_Count = Column(Float)
    Acc_Mid_Count = Column(Float)
    Acc_High_Count = Column(Float)
    Dec_Low_Count = Column(Float)
    Dec_Mid_Count = Column(Float)
    Dec_High_Count = Column(Float)
    Left_Turn_Low_Count = Column(Float)
    Left_Turn_Mid_Count = Column(Float)
    Left_Turn_High_Count = Column(Float)
    Right_Turn_Low_Count = Column(Float)
    Right_Turn_Mid_Count = Column(Float)
    Right_Turn_High_Count = Column(Float)


class TrainBPM(TrainId, PlayerId, Base):
    __abstract__ = True

    id = Column(String(2), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())

    for i in range(0, 60):
        vars()[str(i)] = Column(Integer, server_default="0")
