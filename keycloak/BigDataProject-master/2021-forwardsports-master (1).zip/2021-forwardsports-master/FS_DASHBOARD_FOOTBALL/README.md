# Forward Sports Football App

### Installation
```
Windows
$ git clone https://github.com/nilsleh/fsFootballApp.git
$ cd fsBasketballApp
$ python -m venv myenv
$ .\myenv\Scripts\activate
$ pip install -r requirements.txt
```

```
Mac
$ git clone https://github.com/nilsleh/fsFootballApp.git
$ cd fsBasketballApp
$ python3 -m venv myenv
$ source myenv/bin/activate
$ pip3 install -r requirements.txt
```

### Database
This Application connects the dashboard to a database. After following the installation steps, you will have to implement your own personal connection with the database. This can either be done by creating a .yaml file with the following single line:

```
mysql : 'mysql://<user>:<password>@<port>/<name of db>'
```
and placing it in the database folder, which could be considered more secure. Alternatively, you can create the connection by changing the sql.create_engine() statemtent in line 13 of the database.py file in the database folder:
```
sql_engine=sql.create_engine('mysql://<user>:<password>@<port>/<name of db>')
```

After connecting to the database you can run the application with 
```
$ flask run
```

