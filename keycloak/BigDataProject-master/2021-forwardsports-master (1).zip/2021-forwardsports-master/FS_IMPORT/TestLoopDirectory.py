import os

# Local setting, need to be adapted for each machine
path_basic_info = r'C:\Users\poden\Documents\00 Mijn Transfers\01 LaadData\01 FS-RAW'

# set up folder structure
path_archive =path_basic_info + r'\Archive'
path_archiveduplicates=path_basic_info + r'\ArchiveDuplicates'

# basic folders
full_basic_info = path_basic_info + r'\Basic_info'
full_train_info = path_basic_info + r'\Train_info'
full_extend_info = path_basic_info + r'\Extend_info'

# after import move to archive
path_archive_basic =path_archive+ r'\Basic_info'
path_archive_train=path_archive+ r'\Train_info'
path_archive_extend =path_archive+ r'\Extend_info'

# for already loaded files, move to archive duplicates
path_archiveduplicates_basic =path_archiveduplicates+ r'\Basic_info'
path_archiveduplicates_train=path_archiveduplicates+ r'\Train_info'
path_archiveduplicates_extend =path_archiveduplicates+ r'\Extend_info'

# Insert Basic info

directory = path_archive_basic
for filename in os.listdir(directory):
    if filename.endswith(".xls") or filename.endswith(".xlsx"):
       #print(os.path.join(directory, filename))
        print(filename)
    else:
        continue