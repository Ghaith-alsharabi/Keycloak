import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .database import database as db

import numpy as np
import pandas as pd

def player_current_performance_layout():

    player_number = 11
    team = "AFCU9-1"
    player_id = "72264"

    # check latest match table
    latest_matches, matchDates = db.latest_matches_per_team(team)
    external_df, internal_df, ball_df, performance_df, stamina_AC,gauge_val_dict, trend_df, internal_fit, external_fit, ball_fit = db.latest_matches_per_player(player_id, latest_matches)

    internal_performance = performance_df[performance_df['Parameters'].isin(['exerciseLoad', 'calories', 'maxVO2'])]
    external_performance = performance_df[performance_df['Parameters'].isin(['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',\
                                            'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh', 'runningDistance',\
                                            'maxRunningSpeed', 'maxDribbleSpeed'])]
    ball_performance = performance_df[performance_df['Parameters'].isin(['touches', 'passes', 'shots', 'tackles'])]

    # internal bar charts ##
    internal_bar_df = internal_performance[internal_performance['Parameters'].isin(['maxVO2', 'exerciseLoad', 'calories'])]
    internal_bar_df = internal_fit.copy()
    internal_x = internal_bar_df['Parameters'].to_list()
    internal_y_player = internal_bar_df['Latest Match'].to_list()
    internal_y_max = internal_bar_df['Max Performance'].to_list()

    internal_bar = go.Figure()
    internal_bar.add_trace(
        go.Bar(name='Maximum', x=internal_fit['Parameters'], y=internal_fit['Max Performance']),
    )

    internal_bar.add_trace(
        go.Bar(name='You', x=internal_fit['Parameters'], y=internal_fit['Latest Match'], width=0.6),
    )

    internal_bar.update_layout(template='seaborn', barmode='overlay', hovermode='x', height=500,)

    ## contribution bar charts ##

    # speed 
    speed_bar_df = external_performance[external_performance['Parameters'].isin(['runningDistance'])]
    speed_x = speed_bar_df['Parameters'].to_list()
    speed_y_player = speed_bar_df['Latest Match'].to_list()
    speed_y_max = speed_bar_df['Max Performance'].to_list()
    speed_contribution_bar = go.Figure()

    speed_contribution_bar.add_trace(
        go.Bar(name='Maximum', x=speed_x, y=speed_y_max)
    )

    speed_contribution_bar.add_trace(
        go.Bar(name='You', x=speed_x, y=speed_y_player)
    )

    speed_contribution_bar.update_layout(template='seaborn', barmode='overlay', hovermode='x')

    # IMA Turns
    turns_bar_df = external_performance[external_performance['Parameters'].isin(['imaLeftMid', 'imaLeftHigh', 'imaRighMid', 'imaRighHigh'])]
    turns_x = turns_bar_df['Parameters'].to_list()
    turns_y_player = turns_bar_df['Latest Match'].to_list()
    turns_y_max = turns_bar_df['Max Performance'].to_list()
    turns_contribution_bar = go.Figure()

    turns_contribution_bar.add_trace(
        go.Bar(name='Maximum', x=turns_x, y=turns_y_max),
    )

    turns_contribution_bar.add_trace(
        go.Bar(name='You', x=turns_x, y=turns_y_player, width=0.6),
    )

    turns_contribution_bar.update_layout(template='seaborn', barmode='overlay', hovermode='x')
    turns_contribution_bar.update_xaxes(tickangle=45)

    ## acceleration contribution ##
    acc_bar_df = external_performance[external_performance['Parameters'].isin(['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh'])]
    acc_x = acc_bar_df['Parameters'].to_list()
    acc_y_player = acc_bar_df['Latest Match'].to_list()
    acc_y_max = acc_bar_df['Max Performance'].to_list()
    acc_contribution_bar = go.Figure()

    acc_contribution_bar.add_trace(
        go.Bar(name='Maximum', x=acc_x, y=acc_y_max),
    )

    acc_contribution_bar.add_trace(
        go.Bar(name='You', x=acc_x, y=acc_y_player, width=0.6),
    )

    acc_contribution_bar.update_layout(template='seaborn', barmode='overlay', hovermode='x')
    acc_contribution_bar.update_xaxes(tickangle=45)

    ball_bar_df = ball_performance[ball_performance['Parameters'].isin(['shots', 'touches', 'passes', 'tackles'])]
    ball_x = ball_bar_df['Parameters'].to_list()
    ball_y_player = ball_bar_df['Latest Match'].to_list()
    ball_y_max = ball_bar_df['Max Performance'].to_list()

    ball_bar = go.Figure()
    ball_bar.add_trace(
        go.Bar(name='Maximum', x=ball_x, y=ball_y_max),
    )
    ball_bar.add_trace(
        go.Bar(name='You', x=ball_x, y=ball_y_player, width=0.6),
    )

    ball_bar.update_layout(template='seaborn', barmode='overlay', hovermode='x')

    ### EXCLUDE MAX FROM PERFORMANCE TABLES ###
    internal_performance_current = internal_performance[['Latest Match', 'Parameters', 'FIT Score']]
    external_performance_current = external_performance[['Latest Match', 'Parameters', 'FIT Score']]
    ball_performance_current = ball_performance[['Latest Match', 'Parameters', 'FIT Score']]

    internal_performance_development = internal_performance[['Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    external_performance_development = external_performance[['Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    ball_performance_development = ball_performance[['Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    development_columns = ['Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change']

    def scaling_function(arr, minAllowed, maxAllowed):
        # get array min and max
        arrMin = min(arr)
        arrMax = max(arr)
        transformation = lambda x: ((maxAllowed - minAllowed) * (x - arrMin)) / (arrMax-arrMin) + minAllowed

        scaled_list = list(map(transformation, arr))

        return scaled_list


    def data_bars_diverging_pos_neg(df, column, side, color_above='#3D9970', color_below='#FF4136'):
        numeric_values = df[column].to_list()

        styles = []
        for i in numeric_values:
            style = {
            'if': {
                    'filter_query': (
                        '{{{column}}} = {value}'
                    ).format(column=column, value=i),
                    'column_id': column
                },
                'paddingBottom': 2,
                'paddingTop': 2
            }

            if side=='left':
                background = (
                    """
                        linear-gradient(90deg,
                        white 0%, 
                        white {scalar}%,
                        {color_below} {scalar}%,
                        {color_below} 100%)
                    """.format(
                        color_below=color_below, scalar= i
                    )
                )
            elif side=='right' and i > 200:
                background = (
                    """
                        linear-gradient(90deg,
                        white 0%, 
                        {color_above} 100%,
                        )
                    """.format(
                        color_above=color_above
                    )
                )
            else:
                background = (
                    """
                        linear-gradient(90deg,
                        {color_above} 0%,
                        {color_above} {scalar}%,
                        white {scalar}%,
                        white 100%)
                    """.format(
                        color_above=color_above, scalar= i-99
                    )
                )

            style['background'] = background
            styles.append(style)

        return styles
        
        

    layout = html.Div(children=[
        html.Div([
            dbc.Card([
                dbc.CardBody([

                    html.H5('Internal', style={
                        'textAlign': 'center', }),
                    html.Div([
                        dbc.Button("Total Match Data", id='internal-raw-current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                        dbc.Button("Per Minute Data", id='internal-minute_current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                    ], style={'textAlign': 'center'}),

                    html.Div([

                        dash_table.DataTable(
                            id='internal-data-table-current',
                            columns=[
                                {"name": i, "id": i, "deletable": False, "selectable": True} for i in internal_fit.columns
                            ],
                            data=internal_fit.to_dict(
                                'records'),
                            sort_action="native",
                            style_cell={
                                'textAlign': 'center', 'padding': '5px'},
                            style_as_list_view=False,
                            style_header={
                                'backgroundColor': '#e6e6e6',
                                'font': 16,
                                'fontWeight': 'bold'
                            },
                            style_data={
                                'width': '100px',
                                'maxWidth': '150px',
                                'minWidth': '100px',
                            },
                            style_data_conditional=(
                                data_bars_diverging_pos_neg(internal_fit, 'belowFIT', 'left') +
                                data_bars_diverging_pos_neg(internal_fit, 'aboveFIT', 'right') +
                                [{'if': {'column_id': 'Parameters'},
                                'width': '200px', 'backgroundColor': '#e6e6e6'},
                                {
                                    'if': {'row_index': 'even'},
                                    'backgroundColor': '#b3b3b3'
                                },
                                ] +
                                [
                                    {'if': {'column_id': 'Latest Match'},
                                    'backgroundColor': 'white'},
                                    {'if': {'column_id': 'belowFIT'},
                                    'backgroundColor': 'white'},
                                    {'if': {'column_id': 'aboveFIT'},
                                    'backgroundColor': 'white'},
                                    {'if': {'column_id': 'Max Performance'},
                                    'backgroundColor': 'white'},
                                ]
                            )
                        ),

                    ], style={"width": "70%", 'margin-right': 'auto', 'margin-left': 'auto'}),

                ]),
            ]),

            dcc.Graph(
                id='internal-bar-2',
                figure=internal_bar,
            ),
        ], style={'width': '100%', 'textAlign': 'center'}),
        html.Div([
            dbc.Card([
                dbc.CardBody([

                    html.H5('External', style={
                        'textAlign': 'center',
                    }),
                    html.Div([
                        dbc.Button("Total Match Data", id='external-raw-current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                        dbc.Button("Per Minute Data", id='external-minute-current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                    ], style={'textAlign': 'center'}),
                    dash_table.DataTable(
                        id='external-data-table-current',
                        columns=[
                            {"name": i, "id": i, "deletable": False, "selectable": True} for i in external_performance_current.columns
                        ],
                        data=external_performance_current.to_dict(
                            'records'),
                        style_cell={
                            'textAlign': 'center', 'padding': '5px'},
                        style_as_list_view=True,
                        style_header={
                            'backgroundColor': 'white',
                            'font': 14,
                            'fontWeight': 'bold'
                        },
                        style_data_conditional=[
                            {
                                "if": {
                                    'column_id': 'Parameters',
                                    'filter_query': "{FIT Score} < 100"
                                },
                                'backgroundColor': "#ed4734",
                                'color': 'white',
                            },
                            {
                                "if": {
                                    'column_id': 'Parameters',
                                    'filter_query': "{FIT Score} >= 100"
                                },
                                'backgroundColor': "#1ABE0C",
                                'color': 'white',
                            },
                            {'if': {'column_id': 'Latest Match'},
                            'width': '33%'},
                            {'if': {'column_id': 'Parameters'},
                            'width': '33%'},
                            {'if': {'column_id': 'FIT Score'},
                            'width': '33%'},
                        ]
                    ),
                ]),
            ]),
            dbc.Row([
                dbc.Col([

                    html.H6('Speed in Match', style={
                        'textAlign': 'center'}),
                    dcc.Graph(
                        id='team-contribution-speed',
                        figure=speed_contribution_bar
                    ),
                ]),
                dbc.Col([

                    html.H6('Turns in Match', style={
                        'textAlign': 'center'}),
                    dcc.Graph(
                        id='team-contribution-turns',
                        figure=turns_contribution_bar
                    ),
                ]),
                dbc.Col([

                    html.H6('Accelerations in Match',
                            style={'textAlign': 'center'}),
                    dcc.Graph(
                        id='team-contribution-acc',
                        figure=acc_contribution_bar
                    ),
                ]),
            ])
        ], style={'width': '100%', 'textAlign': 'center'}),
        dbc.Card([
            html.Div([
                dbc.CardBody([
                    html.H5('Ball', style={
                        'textAlign': 'center',
                    }),
                    html.Div([
                        dbc.Button("Total Match Data", id='ball-raw-current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                        dbc.Button("Per Minute Data", id='ball-minute-current', outline=True, color="dark", size="sm",
                                style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                        'margin': '2px 2px'}),
                    ], style={'textAlign': 'center'}),
                    dash_table.DataTable(
                        id='ball-data-table-current',
                        columns=[
                            {"name": i, "id": i, "deletable": False, "selectable": True} for i in ball_performance_current.columns
                        ],
                        data=ball_performance_current.to_dict(
                            'records'),
                        style_cell={
                            'textAlign': 'center', 'padding': '5px'},
                        style_as_list_view=True,
                        style_header={
                            'backgroundColor': 'white',
                            'font': 14,
                            'fontWeight': 'bold'
                        },
                        style_data_conditional=[
                            {
                                "if": {
                                    'column_id': 'Parameters',
                                    'filter_query': "{FIT Score} < 100"
                                },
                                'backgroundColor': "#ed4734",
                                'color': 'white',
                            },
                            {
                                "if": {
                                    'column_id': 'Parameters',
                                    'filter_query': "{FIT Score} >= 100"
                                },
                                'backgroundColor': "#1ABE0C",
                                'color': 'white',
                            },
                            {'if': {'column_id': 'Latest Match'},
                            'width': '33%'},
                            {'if': {'column_id': 'Parameters'},
                            'width': '33%'},
                            {'if': {'column_id': 'FIT Score'},
                            'width': '33%'},
                        ]
                    ),
                ]),
            ])
        ], style={'width': '100%', 'textAlign': 'center'}),
        dcc.Graph(
            id='ball-bar',
            figure=ball_bar,
        ),
    ])

    return layout
