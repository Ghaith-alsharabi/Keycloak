import pandas as pd


def clean_extend_info(dfs_extend_info):
    # Clean Overall Statistics match
    df_extend_match = dfs_extend_info[0]

    df_extend_match[1]['timestamp'] = pd.to_datetime(df_extend_match[1]['timestamp'], errors='coerce')

    # Clean Coord
    df_extend_coord = dfs_extend_info[2]
    for coord in df_extend_coord[1]:
        coord[1].replace({'-': "0"}, inplace=True)

    # Clean Events
    df_extend_events = dfs_extend_info[5]
    for i in df_extend_events[1]:
        for j in df_extend_events[1][i]:
            j[1]['timestamp'] = pd.to_datetime(j[1]['timestamp'])
            j[1].drop(columns="Type", inplace=True)
            j[1].fillna(0, inplace=True)

    # Clean IMA
    df_extend_ima = dfs_extend_info[4]

    for i in df_extend_ima[1]:
        i[1]['timestamp'] = pd.to_datetime(i[1]['timestamp'])
        i[1].drop_duplicates(inplace=True)

    return dfs_extend_info
