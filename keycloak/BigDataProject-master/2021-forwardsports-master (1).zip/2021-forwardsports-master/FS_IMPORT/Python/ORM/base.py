from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import pandas as pd
#import pymysql

#local machine
engine_example = 'mysql+mysqlconnector://root:admin@127.0.0.1/ff_staging'
#engine_example = 'mysql+pymysql://root:admin@127.0.0.1/ff_staging'
engine_stg = create_engine(engine_example)

# API Base
Base = declarative_base()
# Staging Base
Stg_Base = declarative_base(metadata=MetaData(schema='ff_staging'))

# Session
SessionStg = sessionmaker(bind=engine_stg)


# Function to reset the Staging Database
def reset_db(base, engine):
    base.metadata.drop_all(engine)
    base.metadata.create_all(engine)
    print("Tables for Staging Database created")


def already_loaded(sql_engine, param):
    connection = sql_engine.raw_connection()
    try:
        cursor = connection.cursor()
        cursor.callproc('ADMIN_01_CHECK_ALREADY_LOADED',param) 
        for row in cursor.stored_results(): 
            results = row.fetchall()
            colNamesList=row.description
 
        colNames=[i[0] for i in colNamesList]
        result_dicts = [dict(zip(colNames, row)) for row in results]
        result_df=pd.DataFrame(result_dicts)
        cursor.close()

        return result_df['isLoaded'].values[0]
    finally:
        connection.close()

# Create a connection object to the MySQL Database Server

# hostName        = "127.0.0.1"
# userName        = "root"
# userPassword    = "admin"
# databaseName    = "ff_staging"

# cursorType      = pymysql.cursors.DictCursor

# connection   = pymysql.connect(host=hostName,user=userName,password=userPassword,db=databaseName,cursorclass=cursorType)

# def already_loaded_v1(connection, param):
   
#     try:
#         cursorObject    = connection.cursor() 
#         cursorObject.execute('ADMIN_01_CHECK_ALREADY_LOADED',param) 
#         for result in cursorObject.fetchall():
#             print(result)
#     except Exception as e:
#         print("Exception occured:{}".format(e))
#     # finally:
#     #     connection.close()
       