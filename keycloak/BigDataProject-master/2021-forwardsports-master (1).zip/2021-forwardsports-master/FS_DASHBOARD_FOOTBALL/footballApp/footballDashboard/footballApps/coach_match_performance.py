import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State, MATCH, ALL
import dash_table

import pandas as pd
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objs as go

from .database import database as db

def coach_match_performance_layout(football_app):

    my_team_name = 'AFCU9-1'
    player_id = "72264"

    # available dates
    available_dates = db.time_range_matches(my_team_name)

    # Possible matches for his team
    possible_team_matches = db.teams_and_matches(my_team_name)

    layout = html.Div(children=[

        html.Details(children=[
            html.Summary("Match Selection"),

            html.Div(id='time-selection-dropdown', children=[
                html.Div([
                    html.H6('Select Time Period Start',
                            style={'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='select-start-time-coach',
                        options=[{'label': i, 'value': i}
                                for i in available_dates],
                        value=available_dates[0]
                    ),
                ], style={'display': 'inline-block', 'width': '33%', }),
                html.Div([
                    html.H6('Select Time Period End',
                            style={'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='select-end-time-coach',
                        options=[{'label': i, 'value': i}
                                for i in available_dates],
                        value=available_dates[-1]
                    ),
                ], style={'display': 'inline-block', 'width': '33%', }),
                html.Div([
                    html.H6('Select Match', style={'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-select-coach',
                        options=[{'label': i, 'value': i}
                                for i in possible_team_matches],
                        value=possible_team_matches[0],
                        clearable=False
                    ),
                ], style={'display': 'inline-block', 'width': '33%', }),

            ], style={'margin-top': '10px', 'padding-bottom': '10px'}),
        ]),

        dash_table.DataTable(
            id='datatable-coach',
            # columns=[
            #     {"name": i, "id": i, "selectable": True} for i in match_df.columns
            # ],
            # data=dummy_df.to_dict('records'),
            sort_action="native",
            sort_mode="multi",
            style_table={
                'overflowX': 'auto',
                'minWidth': '100%',
                'height': '300px',
                'overflowY': 'auto'
            },
            page_action='none',
            selected_columns=[],
            selected_rows=[],
            row_selectable="multi",
            #fixed_columns={'headers': True, 'data':1},
            #fixed_rows={'headers': True, 'data': 0},
            # style_table={'minWidth': '100%'},
            column_selectable="multi",
            style_cell={
                'textAlign': 'center',
                'minWidth': '80px', 'width': '100px', 'maxWidth': '180px',
            },
            # style_cell_conditional=[
            #     {
            #         'if': {'column_id': c},
            #         'textAlign': ''
            #     } for c in ['Date', 'Region']
            # ],
            style_data_conditional=[
                {
                    'if': {'row_index': 'odd'},
                    'backgroundColor': 'rgb(248, 248, 248)'
                }
            ],
            style_header={
                'backgroundColor': 'rgb(230, 230, 230)',
                'fontWeight': 'bold'
            }
        ),
        html.Div(id='datatable-plots-coach', children=[
            html.Div(id='datatable-plot-bar',
                    style={'display': 'inline-block', 'width': '59%'}),
            html.Div(id='datatable-plot-trend',
                    style={'display': 'inline-block', 'width': '39%'}),
        ])
    ])  # end match performance tab

    # init callbacks
    init_coach_match_performance_callbacks(football_app)

    return layout

#######################################

################ CALLBACKS #############

########################################

def init_coach_match_performance_callbacks(football_app):

    ### callback to update table with game data ###
    @football_app.callback(
        [Output('datatable-coach', 'columns'),
        Output('datatable-coach', 'data')],
        [Input('match-select-coach', 'value')]
    )
    def update_datatable(match):
        match_df = db.select_match_data(match)
        columns = [
            {"name": i, "id": i, "selectable": True} for i in match_df.columns.tolist()
        ]
        data = match_df.to_dict('records')
        return columns, data

    # callback to update chart yielded from table selection


    @football_app.callback(
        [Output('datatable-plot-bar', 'children'),
        Output('datatable-plot-trend', 'children')],
        [Input('match-select-coach', 'value'),
        Input('datatable-coach', 'derived_virtual_data'),
        Input('datatable-coach', 'derived_virtual_selected_rows'),
        Input('datatable-coach', 'selected_columns'),
        Input('datatable-coach', 'active_cell')]
    )
    def update_data_table(match, rows, derived_virtual_selected_rows, cols, active_cell):
        # when no rows are selected

        if derived_virtual_selected_rows and derived_virtual_selected_rows is not None and cols:

            # always append playerId columns so you can filter by it
            cols.append("playerId")

            # collect playerIds
            player_ids = []
            for i in derived_virtual_selected_rows:
                player_ids.append(rows[i]['playerId'])

            # select match data
            dff = db.select_match_data(match)

            # filter by selected columns
            dff = dff[cols]

            # append an average column
            dff.loc['Team Average'] = dff.mean()
            dff.at['Team Average', 'playerId'] = 'Team Average'

            # append "average" to player_ids
            player_ids.append('Team Average')

            # add color condition so there is distinction between metrics like average and player data
            avg_color = '#ff944d'  # light orange
            normal_color = '#66b3ff'  # light blue
            selected_color = '#0059b3'  # darker blue

            # if active cell is in the list of players
            if active_cell is not None:

                # get the corresponding player id
                selected_value = str(rows[active_cell['row']]['playerId'])
            else:
                selected_value = 'nothing'

            condlist = [dff['playerId'] == 'Team Average', dff['playerId']
                        == selected_value, dff['playerId'] != 'Team Average']
            choicelist = [avg_color, selected_color, normal_color]
            dff['color'] = np.select(condlist, choicelist)

            # filter by selected players
            dff = dff[dff['playerId'].isin(player_ids)]

            # take out player Id out of cols so it is not plotted
            cols.remove('playerId')

            # create fig by having sorted displays of selected columns comparing players
            children_bar = []

            for column in cols:
                # filter by respective column
                plot_df = dff[['playerId', 'color', column]]

                # order in descending
                plot_df.sort_values(by=column, ascending=False, inplace=True)

                chart_bar = dcc.Graph(
                    id={
                        'type': 'column-table-select',
                        'index': column
                    },
                    figure={
                        "data": [
                            {
                                "x": plot_df['playerId'],
                                "y": plot_df[column],
                                "type": "bar",
                                "marker": {
                                    "color": plot_df['color']
                                },
                            }
                        ],
                        "layout": {
                            "xaxis": {"automargin": True, "type": 'category'},
                            "yaxis": {
                                "automargin": True,
                                "title": {"text": column}
                            },
                            "height": 300,
                            "margin": {"t": 10, "l": 10, "r": 10},
                        },
                    },
                )

                # append chart to fig list
                children_bar.append(chart_bar)

            #### line chart ####

            ### get match data for the selected player_ids ###
            player_matches_df = db.match_data_list_players(player_ids)

            # add colors to data
            # condlist = [player_matches_df['playerId']=='Team Average', player_matches_df['playerId']==selected_value, player_matches_df['playerId']!='Team Average']
            # choicelist = [avg_color, selected_color, normal_color]
            # player_matches_df['color'] = np.select(condlist, choicelist)

            # sort by match_id
            player_matches_df.sort_values(by='matchId', inplace=True)
            # get list of player_ids
            players_and_mean = player_matches_df['playerId'].unique().tolist()

            children_line = []

            # per selected variable create one line chart over all games
            for column in cols:
                plot_df = player_matches_df[['playerId', 'matchId', column]]

                # create a figure
                fig = go.Figure()

                # use traces to append trace per player
                for p in players_and_mean:
                    line_df = plot_df[plot_df['playerId'] == p]

                    # get the correct color
                    if p == 'Team Average':
                        color = avg_color
                    elif p == selected_value:
                        color = selected_color
                    else:
                        color = normal_color

                    fig.add_trace(
                        go.Scatter(
                            x=line_df['matchId'],
                            y=line_df[column],
                            mode='lines+markers',
                            marker_color=color,
                            name=p
                        )
                    )

                    # add vertical line for the current selected match
                    fig.add_shape(
                        # Line Vertical
                        dict(
                            type="line",
                            xref="x",
                            yref="y",
                            x0=match,
                            y0=0,
                            x1=match,
                            y1=line_df[column].max(),
                            line=dict(
                                color="Black",
                                width=3,
                                dash="dot",
                            )
                        ))

                # updata fig layout
                fig.update_layout(
                    xaxis={
                        'automargin': True,
                        'type': 'category'
                    },
                    yaxis={
                        # 'automargin': True,
                        'title': {'text': column}
                    },
                    height=300,
                    width=700,
                    margin={"t": 10, "l": 10, "r": 5},
                    hovermode='x unified',
                    template='plotly_white',
                    showlegend=False
                )

                # append as dcc.Graph element
                chart_line = dcc.Graph(
                    id={
                        # 'type': 'column-table-select',
                        'index': column
                    },
                    figure=fig
                )

                children_line.append(chart_line)

        else:
            children_bar = []
            children_line = []

        return children_bar, children_line
