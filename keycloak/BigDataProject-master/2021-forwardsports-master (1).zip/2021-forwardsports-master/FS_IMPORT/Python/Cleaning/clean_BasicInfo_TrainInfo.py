import pandas as pd


def clean_basic_info(dfs_basic_info):

    df_basic_info = dfs_basic_info[0]
    df_basic_players = dfs_basic_info[1]

    # Change match date type (string) to datetime
    df_basic_info[1]['Match date'] = pd.to_datetime(df_basic_info[1]['Match date'], errors="coerce")

    # Separate Opponents Column in 4 Columns: ["team1"], ["team2"], [score_team1], [score_team2]
    opponents = df_basic_info[1].iloc[0]['Opponents']
    opponents = opponents.replace(" ：", ":")
    df_basic_info[1]["Opponents"] = opponents
    opponents = opponents.split(":")
    df_basic_info[1]["Team_A"] = opponents[0][:-2]
    df_basic_info[1]["Score_Team_A"] = int(opponents[0][-2:])
    df_basic_info[1]["Team_B"] = opponents[1][2:]
    df_basic_info[1]["Score_Team_B"] = int(opponents[1][:2])

    # Replace Position column, all values 0's
    df_basic_players[1].replace({'-': "0"}, inplace=True)
    df_basic_players[1]['Birthday'] = pd.to_datetime(df_basic_players[1]['Birthday'], errors="coerce")
    df_basic_players[1]['Intensive Runs Avg. Intervals'] = df_basic_players[1]['Intensive Runs Avg. Intervals'].astype(
        float)

    return dfs_basic_info


def clean_train_info(dfs_train_info):
    # Fill with 0 Nan values
    for i in range(3, len(dfs_train_info), 2):
        dfs_train_info[i][1].fillna(0, axis=0, inplace=True)

    return dfs_train_info
