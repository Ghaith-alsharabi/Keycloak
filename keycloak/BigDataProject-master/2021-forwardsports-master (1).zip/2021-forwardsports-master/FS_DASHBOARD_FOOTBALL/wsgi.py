"""Application entry point."""
from footballApp import init_app

#footballApp, basketballApp = init_app()
footballApp = init_app()

if __name__ == "__main__":
    footballApp.run(host='0.0.0.0')
    #basketballApp.run(host='0.0.0.0')
