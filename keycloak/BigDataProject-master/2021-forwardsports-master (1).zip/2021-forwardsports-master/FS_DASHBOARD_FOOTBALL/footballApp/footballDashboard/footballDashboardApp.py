import dash
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output

from .footballApps import commonmodules
from .footballApps import home #, club, player  # coach
from .footballApps import coach_profile, coach_match_performance, coach_training_match, \
    coach_in_depth_player, coach_tactical_analysis, coach_match_comparison
from .footballApps import player_my_profile, player_current_performance, player_match_comparison, \
    player_match_performance_trend, player_development

def init_dashboard(server):
    "Create the plotly Dash Football dashboard"
    football_app = dash.Dash(
        server=server,
        routes_pathname_prefix='/footballDashApp/',
        external_stylesheets=[
            # '/static/dist/css/styles.css',
            # 'https://fonts.googleapis.com/css?family=Lato',
            dbc.themes.BOOTSTRAP,
        ]
    )

    # create layout
    football_app.layout = html.Div([
        dcc.Location(id='url', refresh=False),
        html.Div(id='page-content')
    ])

    # initiate the callbacks for the page navigation
    init_callbacks(football_app)

    # initiate callbacks for other pages and tabs
    player_match_comparison.init_player_match_comparison_callbacks(football_app)
    player_match_performance_trend.init_player_match_performance_trend_callbacks(football_app)

    coach_match_performance.init_coach_match_performance_callbacks(football_app)
    coach_tactical_analysis.init_coach_tactical_analysis_callbacks(football_app)
    coach_match_comparison.init_coach_match_comparison_callbacks(football_app)

    return football_app.server


def init_callbacks(football_app):
    @football_app.callback(Output('page-content', 'children'),
                [Input('url', 'pathname')])
    def display_page(pathname):
        if pathname == '/footballDashApp/':
            return home.home_layout(),

        elif pathname == '/footballDashApp/player':
            return html.Div([
                commonmodules.get_header(),
                commonmodules.get_menu(),
                dcc.Tabs(id="player-tabs", children=[
                    dcc.Tab(label="My Profile", children=[
                        player_my_profile.player_my_profile_layout(),
                    ]),
                    dcc.Tab(label="Current Performance", children=[
                        player_current_performance.player_current_performance_layout(),
                    ]),
                    dcc.Tab(label="Player Development", children=[
                        player_development.player_development_layout(),
                    ]),
                    dcc.Tab(label="Match Performance Trend", children=[
                        player_match_performance_trend.player_match_performance_trend_layout(football_app),
                    ]),
                    dcc.Tab(label="Match Comparison", children=[
                        player_match_comparison.player_match_comparison_layout(football_app),
                    ]),
                ])
            ])

        elif pathname == '/footballDashApp/coach':
            return html.Div([
                commonmodules.get_header(),
                commonmodules.get_menu(),
                dcc.Tabs(id="coach-tabs", children=[
                    dcc.Tab(label="My Profile", children=[
                            coach_profile.coach_profile_layout(),
                    ]),
                    dcc.Tab(label="Match Performance", children=[
                            coach_match_performance.coach_match_performance_layout(football_app),
                    ]),
                    dcc.Tab(label="Training/Match", children=[
                            coach_training_match.coach_training_match_layout(),
                    ]),
                    dcc.Tab(label="In Depth Player", children=[
                            coach_in_depth_player.coach_in_depth_player_layout(),
                    ]),
                    dcc.Tab(label="Tactical Analysis", children=[
                            coach_tactical_analysis.coach_tactical_analysis_layout(football_app),
                    ]),
                    dcc.Tab(label="Match Comparison", children=[
                            coach_match_comparison.coach_match_comparison_layout(football_app),
                    ])
                ]),
            ])
        # elif pathname == '/club':
        #     return club.layout
        else:
            return '404'


# if __name__ == '__main__':
#     app.run_server(debug=True)
