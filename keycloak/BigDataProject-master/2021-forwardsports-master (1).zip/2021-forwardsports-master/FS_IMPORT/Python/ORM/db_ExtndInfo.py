from sqlalchemy import Column, String, ForeignKey, DateTime, Float, Boolean, func, Integer, \
    PrimaryKeyConstraint
from sqlalchemy.orm import relationship, backref
from sqlalchemy.ext.declarative import declared_attr
from Python.ORM.base import Base


class ExtendMatch(Base):
    __abstract__ = True

    Match_id = Column(String(255), primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    App_Version = Column(String(10))
    Algorithm_Version = Column(Integer)
    Match_Type = Column(String(20))
    Match_Duration = Column(String(20))
    Date = Column(DateTime)


class MatchID(object):
    @declared_attr
    def match_id(self):
        match_id = Column("Match_id", String(255),
                          ForeignKey('extend_match.Match_id', name='%s_related_match_id' % self.__tablename__,
                                     ondelete="cascade", onupdate="cascade"))
        return match_id

    @declared_attr
    def match(self):
        match = relationship("ExtendMatch", backref=backref("extend_match"), foreign_keys=[self.match_id])
        return match


class ExtendPlayers(MatchID, Base):
    __abstract__ = True

    Player_id = Column(Integer, primary_key=True)
    Extracted_File = Column(String(255), primary_key=True)
    Load_datetime = Column(DateTime, server_default=func.now())
    Name = Column(String(255))
    HR_Max = Column(Integer)
    VO2_Max = Column(Integer)
    Calories = Column(Float)
    Physic_Load = Column(Float)
    Distance_Covered = Column(Float)
    Highest_Speed = Column(Float)
    Highest_Dribble = Column(Float)
    IMA_Acc_Low = Column(Integer)
    IMA_Acc_Mid = Column(Integer)
    IMA_Acc_High = Column(Integer)
    IMA_Dec_Low = Column(Integer)
    IMA_Dec_Mid = Column(Integer)
    IMA_Dec_High = Column(Integer)
    IMA_Right_Low = Column(Integer)
    IMA_Right_Mid = Column(Integer)
    IMA_Right_High = Column(Integer)
    IMA_Left_Low = Column(Integer)
    IMA_Left_Mid = Column(Integer)
    IMA_Left_High = Column(Integer)
    Dribble_Distance = Column(Float)
    Ball_Possession_Time = Column(Integer)
    Passes = Column(Integer)
    Shots = Column(Integer)
    Tackles_Interceptions = Column(Integer)

    PrimaryKeyConstraint("Player_id", "Match_id", "Extracted_File", name="extend_players_pk")


class PlayerId(object):
    @declared_attr
    def player_id(self):
        player_id = Column("Player_id", Integer,
                           ForeignKey('extend_players.Player_id', name='%s_related_player_id' % self.__tablename__,
                                      ondelete="cascade", onupdate="cascade"),
                           primary_key=True)
        return player_id

    @declared_attr
    def player(self):
        player = relationship("ExtendPlayers", backref=backref("extend_players"), foreign_keys=[self.player_id])
        return player


class ExtendCoordBall(MatchID, Base):
    __abstract__ = True

    id = Column(Integer, primary_key=True, autoincrement=True)
    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    ball_id = Column(String(255))
    TimeStamp = Column(String(255))


class ExtendCoordPlayers(MatchID, PlayerId, Base):
    __abstract__ = True

    id = Column(Integer, primary_key=True, autoincrement=True)
    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    TimeStamp = Column(String(255))


class ExtendIntervals(MatchID, PlayerId, Base):
    __abstract__ = True

    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    TimeStamp = Column(String(255), primary_key=True)
    HR_Max = Column(Integer)
    VO2_Max = Column(Integer)
    Dribble_Distance = Column(Float)
    Ball_Possession_Time = Column(Integer)
    Calories = Column(Float)
    Physic_Load = Column(Float)
    Distance_Covered = Column(Float)
    HR_Count = Column(Integer)
    Highest_Speed = Column(Float)
    Highest_Dribble = Column(Float)


class ExtendEventPass(MatchID, PlayerId, Base):
    __abstract__ = True

    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    TimeStamp = Column(DateTime, primary_key=True)
    posX = Column(Integer)
    posY = Column(Integer)
    received_PosX = Column(Integer)
    received_PosY = Column(Integer)
    isForward = Column(Boolean)
    isSucceeded = Column(Boolean)
    receiver_id = Column(Integer)


class ExtendEventShot(MatchID, PlayerId, Base):
    __abstract__ = True

    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    TimeStamp = Column(DateTime, primary_key=True)
    posX = Column(Integer)
    posY = Column(Integer)


class ExtendEventTackle(MatchID, PlayerId, Base):
    __abstract__ = True

    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    TimeStamp = Column(DateTime, primary_key=True)
    posX = Column(Integer)
    posY = Column(Integer)


class ExtendIma(MatchID, PlayerId, Base):
    __abstract__ = True

    id = Column(Integer, autoincrement=True, primary_key=True)
    Extracted_File = Column(String(255))
    Load_datetime = Column(DateTime, server_default=func.now())
    Type = Column(String(255))
    Intensity = Column(String(255))
    TimeStamp = Column(DateTime)
    Angle = Column(Float)
    Intensity_Val = Column(Float)
    Distance = Column(Float)
    Duration = Column(Float)
    Begin_Speed = Column(Float)
