import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from .database import database as db

import numpy as np
import pandas as pd

def player_development_layout():

    team = "AFCU9-1"
    player_id = "72264"

    # check latest match table
    latest_matches, matchDates = db.latest_matches_per_team(team)
    external_df, internal_df, ball_df, performance_df, stamina_AC, gauge_val_dict, trend_df, internal_fit, external_fit, ball_fit = db.latest_matches_per_player(
        player_id, latest_matches)

    internal_performance = performance_df[performance_df['Parameters'].isin(
        ['exerciseLoad', 'calories', 'maxVO2'])]
    external_performance = performance_df[performance_df['Parameters'].isin(['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',
                                                                            'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh', 'runningDistance',
                                                                            'maxRunningSpeed', 'maxDribbleSpeed'])]
    ball_performance = performance_df[performance_df['Parameters'].isin(
        ['touches', 'passes', 'shots', 'tackles'])]

    ### EXCLUDE MAX FROM PERFORMANCE TABLES ###
    internal_performance_current = internal_performance[[
        'Latest Match', 'Parameters', 'FIT Score']]
    external_performance_current = external_performance[[
        'Latest Match', 'Parameters', 'FIT Score']]
    ball_performance_current = ball_performance[[
        'Latest Match', 'Parameters', 'FIT Score']]

    internal_performance_development = internal_performance[[
        'Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    external_performance_development = external_performance[[
        'Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    ball_performance_development = ball_performance[[
        'Last Week', 'Parameters', 'Average 4 Weeks', 'Percent Change', 'percentChange']]
    development_columns = ['Last Week', 'Parameters',
                        'Average 4 Weeks', 'Percent Change']

    ### Performance Development STUFF ###
    all_matches = db.all_match_data_per_team(team, player_id)
    # all_matches_list = all_matches['matchId'].to_list()
    # internal_parameters = ['exerciseLoad', 'maxVO2']
    # external_parameters = ['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',
    #                     'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh']
    # ball_parameters = ['touches', 'passes', 'shots', 'tackles']

    layout = html.Div(children=[
        html.Div([
            html.H5('Internal', style={'textAlign': 'center'}),
            html.Div([
                dbc.Button("Total Match Data", id='internal-raw-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
                dbc.Button("Per Minute Data", id='internal-minute-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
            ], style={'textAlign': 'center'}),
            dash_table.DataTable(
                id='internal-data-table-performance',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": True} for i in development_columns
                ],
                data=internal_performance_development.to_dict(
                    'records'),
                style_cell={
                    'textAlign': 'center', 'padding': '5px'},
                style_as_list_view=True,
                style_header={
                    'backgroundColor': 'white',
                    'font': 14,
                    'fontWeight': 'bold'
                },
                style_data_conditional=[
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} <= 0"
                        },
                        'backgroundColor': "#ed4734",
                        'color': 'white',
                    },
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} > 0"
                        },
                        'backgroundColor': "#1ABE0C",
                        'color': 'white',
                    },
                    {'if': {'column_id': 'Last Week'},
                    'width': '24%'},
                    {'if': {'column_id': 'Parameters'},
                    'width': '24%'},
                    {'if': {'column_id': 'Average 4 Weeks'},
                    'width': '24%'},
                    {'if': {'column_id': 'Percent Change'},
                    'width': '24%'},
                ]
            ),
        ]),
        html.Div([
            html.H5('External', style={'textAlign': 'center'}),
            html.Div([
                dbc.Button("Total Match Data", id='external-raw-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
                dbc.Button("Per Minute Data", id='external-minute-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
            ], style={'textAlign': 'center'}),
            dash_table.DataTable(
                id='external-data-table-performance',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": True} for i in development_columns
                ],
                data=external_performance_development.to_dict(
                    'records'),
                style_cell={
                    'textAlign': 'center', 'padding': '5px'},
                style_as_list_view=True,
                style_header={
                    'backgroundColor': 'white',
                    'font': 14,
                    'fontWeight': 'bold'
                },
                style_data_conditional=[
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} <= 0"
                        },
                        'backgroundColor': "#ed4734",
                        'color': 'white',
                    },
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} > 0"
                        },
                        'backgroundColor': "#1ABE0C",
                        'color': 'white',
                    },
                    {'if': {'column_id': 'Last Week'},
                    'width': '24%'},
                    {'if': {'column_id': 'Parameters'},
                    'width': '24%'},
                    {'if': {'column_id': 'Average 4 Weeks'},
                    'width': '24%'},
                    {'if': {'column_id': 'Percent Change'},
                    'width': '24%'},
                ]
            ),
        ]),
        html.Div([
            html.H5('Ball', style={'textAlign': 'center'}),
            html.Div([
                dbc.Button("Total Match Data", id='ball-raw-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
                dbc.Button("Per Minute Data", id='ball-minute-development', outline=True, color="dark", size="sm",
                        style={'width': '150px', 'padding': '5px 5px', 'text-align': 'center', 'display': 'inline-block',
                                'margin': '2px 2px'}),
            ], style={'textAlign': 'center'}),

            dash_table.DataTable(
                id='ball-data-table-performance',
                columns=[
                    {"name": i, "id": i, "deletable": False, "selectable": True} for i in development_columns
                ],
                data=ball_performance_development.to_dict(
                    'records'),
                style_cell={
                    'textAlign': 'center', 'padding': '5px'},
                style_as_list_view=True,
                style_header={
                    'backgroundColor': 'white',
                    'font': 14,
                    'fontWeight': 'bold'
                },
                style_data_conditional=[
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} <= 0"
                        },
                        'backgroundColor': "#ed4734",
                        'color': 'white',
                    },
                    {
                        "if": {
                            'column_id': 'Parameters',
                            'filter_query': "{percentChange} > 0"
                        },
                        'backgroundColor': "#1ABE0C",
                        'color': 'white',
                    },
                    {'if': {'column_id': 'Last Week'},
                    'width': '24%'},
                    {'if': {'column_id': 'Parameters'},
                    'width': '24%'},
                    {'if': {'column_id': 'Average 4 Weeks'},
                    'width': '24%'},
                    {'if': {'column_id': 'Percent Change'},
                    'width': '24%'},
                ]
            ),
        ])
    ])

    return layout
