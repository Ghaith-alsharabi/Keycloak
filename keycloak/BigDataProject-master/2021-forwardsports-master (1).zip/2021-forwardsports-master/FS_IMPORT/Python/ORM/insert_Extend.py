from Python.ORM.base import engine_stg
from Python.Read_excels.read_ExtndInfo import ExtendInfo
from Python.Cleaning.clean_ExtInfo import clean_extend_info


def insert_extend(path_extend_info):
    # Read Extend Info excel
    dfs_extend_info = ExtendInfo(path_extend_info)

    # Clean the data frames of Extend Info
    dfs_extend_info_cleaned = clean_extend_info(dfs_extend_info.excel_to_df())

    # Accessing to the different dfs in Basic Info
    df_extend_info = dfs_extend_info_cleaned[0]
    df_extend_players = dfs_extend_info_cleaned[1]
    df_extend_coord = dfs_extend_info_cleaned[2]
    df_extend_intervals = dfs_extend_info_cleaned[3]
    df_extend_ima = dfs_extend_info_cleaned[4]
    df_extend_event = dfs_extend_info_cleaned[5]

    # Renaming the name of the columns of the dfs so it matches with the columns inside the
    # correspondent tables
    # Extend Info Match
    names_extend_info = ["Match_id", "App_Version", "Algorithm_Version", "Match_Type", "Match_Duration", "Date"]
    df_extend_info[1].columns = names_extend_info
    df_extend_info[1]["Extracted_File"] = dfs_extend_info.path.split("\\")[-1]

    # Extend Info Players
    names_extend_players = ["Player_id", "Name", "HR_Max", "VO2_Max", "Calories", "Physic_Load",
                            "Distance_Covered", "Highest_Speed", "Highest_Dribble", "IMA_Acc_Low", "IMA_Acc_Mid",
                            "IMA_Acc_High", "IMA_Dec_Low", "IMA_Dec_Mid", "IMA_Dec_High", "IMA_Right_Low",
                            "IMA_Right_Mid",
                            "IMA_Right_High", "IMA_Left_Low", "IMA_Left_Mid", "IMA_Left_High", "Dribble_Distance",
                            "Ball_Possession_Time", "Passes", "Shots", "Tackles_Interceptions"]

    df_extend_players[1].columns = names_extend_players
    df_extend_players[1]["Extracted_File"] = dfs_extend_info.path.split("\\")[-1]
    df_extend_players[1]["Match_id"] = df_extend_players[0].split("/")[0]

    # Extend Info Coordinates (Ball and Players)
    names_extend_coord_ball = ["TimeStamp", "ball_id", "pos_X", "pos_Y"]
    names_extend_coord_players = ["pos_X", "pos_Y", "TimeStamp"]

    df_extend_coord_ball = []
    df_extend_coord_players = []
    for coord in df_extend_coord[1]:
        if "ball" in coord[0]:
            coord[1].columns = names_extend_coord_ball
            coord[1]["Extracted_File"] = dfs_extend_info.path.split("\\")[-1]
            coord[1]["Match_id"] = df_extend_coord[0].split("/")[0]
            df_extend_coord_ball.append(coord)

        else:
            add_columns(coord, df_extend_coord, names_extend_coord_players, dfs_extend_info.path)
            df_extend_coord_players.append(coord)

    # Extend Info Intervals
    names_extend_intervals = ["TimeStamp", "HR_Max", "VO2_Max", "Dribble_Distance", "Ball_Possession_Time", "Calories",
                              "Physic_Load", "Distance_Covered", "HR_Count", "Highest_Speed", "Highest_Dribble"]
    for interval in df_extend_intervals[1]:
        add_columns(interval, df_extend_intervals, names_extend_intervals, dfs_extend_info.path)

    # Extend Info IMA Data
    names_extend_ima = ["Type", "Intensity", "TimeStamp", "Angle", "Intensity_Val", "Distance", "Duration",
                        "Begin_Speed"]
    for ima in df_extend_ima[1]:
        add_columns(ima, df_extend_ima, names_extend_ima, dfs_extend_info.path)

    # Extend Info Event Pass
    names_extend_event_pass = ["TimeStamp", "posX", "posY", "received_PosX", "received_PosY", "isForward",
                               "isSucceeded",
                               "receiver_id"]
    for event_pass in df_extend_event[1]["Pass"]:
        add_columns(event_pass, df_extend_event, names_extend_event_pass, dfs_extend_info.path)

    # Extend Info Event Shot
    names_extend_event_shot = ["TimeStamp", "posX", "posY"]
    for event_shot in df_extend_event[1]["Shot"]:
        add_columns(event_shot, df_extend_event, names_extend_event_shot, dfs_extend_info.path)

    # Extend Info Event Tackle
    names_extend_event_tackle = ["TimeStamp", "posX", "posY"]
    for event_tackle in df_extend_event[1]["Tackle"]:
        add_columns(event_tackle, df_extend_event, names_extend_event_tackle, dfs_extend_info.path)

    # Establishing a connection to the database
    connection = engine_stg.connect()

    try:

        # Inserting Extend Info dfs
        df_extend_info[1].to_sql(name="extend_match", con=connection, if_exists='append', index=False)
        df_extend_players[1].to_sql(name="extend_players", con=connection, if_exists='append', index=False)

        for coord_ball in df_extend_coord_ball:
            coord_ball[1].to_sql(name="extend_coordinates_ball", con=connection,
                                 if_exists='append', index=False)

        for coord_player in df_extend_coord_players:
            coord_player[1].to_sql(name="extend_coordinates_players", con=connection,
                                   if_exists='append', index=False)

        for interval in df_extend_intervals[1]:
            interval[1].to_sql(name="extend_intervals", con=connection, if_exists='append', index=False)

        for ima in df_extend_ima[1]:
            ima[1].to_sql(name="extend_ima", con=connection, if_exists='append', index=False)

        for event_pass in df_extend_event[1]["Pass"]:
            event_pass[1].to_sql(name="extend_events_pass", con=connection, if_exists='append', index=False)

        for event_shot in df_extend_event[1]["Shot"]:
            event_shot[1].to_sql(name="extend_events_shot", con=connection, if_exists='append', index=False)

        for event_tackle in df_extend_event[1]["Tackle"]:
            event_tackle[1].to_sql(name="extend_events_tackle", con=connection, if_exists='append', index=False)

    except ValueError as vx:
        print(vx)

    except Exception as ex:
        print(ex)

    else:
        print("Inserted data Extended Info: {" + dfs_extend_info.path.split("\\")[-1] + "}")
    finally:
        connection.close()


def add_columns(event, events, names, path):
    event[1].columns = names
    event[1]["Extracted_File"] = path.split("\\")[-1]
    event[1]["Match_id"] = events[0].split("/")[0]
    event[1]["Player_id"] = event[0].split("/")[0]
