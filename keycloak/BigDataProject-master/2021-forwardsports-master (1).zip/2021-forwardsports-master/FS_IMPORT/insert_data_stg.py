from Python.ORM.final_staging_schema import *
from Python.ORM.insert_Basic_Train import insert_basic, insert_train
from Python.ORM.insert_Extend import insert_extend
from Python.ORM.base import engine_stg, Stg_Base, reset_db,already_loaded
# import glob #, shutil
import time
import os

start = time.time()

# Create Tables in Staging Database
reset_db(Stg_Base, engine_stg)


# Local setting, need to be adapted for each machine
path_local = r'C:\Users\poden\Documents\00 Mijn Transfers\01 LaadData\01 FS-RAW'

# set up folder structure
str_import=r'\Import'
str_archive =r'\Archive'
str_archive_duplicates= r'\ArchiveDuplicates'
str_rejected=r'\Rejected'

str_basic=r'\Basic_info'
str_training= r'\Train_info'
str_extend=r'\Extend_info'


# Insert Basic info
str_load=str_basic

path_import =path_local + str_import + str_load
path_archive=path_local + str_archive + str_load
path_archive_duplicates=path_local + str_archive_duplicates + str_load

for fileName in os.listdir(path_import):  
    if (fileName.endswith(".xls") or fileName.endswith(".xlsx")) :
        param=[fileName]
        isAlreadyLoaded= already_loaded(engine_stg, param)
        fileNameFull=os.path.join(path_import, fileName)
        if (isAlreadyLoaded == 0):
            insert_basic(fileNameFull)
            fileNameMoved=os.path.join(path_archive,fileName)
            os.replace(fileNameFull,fileNameMoved) 
        else:
            fileNameMoved=os.path.join(path_archive_duplicates,fileName)
            os.replace(fileNameFull,fileNameMoved)  

# Insert Train Info
str_load=str_training

path_import =path_local + str_import + str_load
path_archive=path_local + str_archive + str_load
path_archive_duplicates=path_local + str_archive_duplicates + str_load

for fileName in os.listdir(path_import):  
    if (fileName.endswith(".xls") or fileName.endswith(".xlsx")) :
        param=[fileName]
        isAlreadyLoaded= already_loaded(engine_stg, param)
        fileNameFull=os.path.join(path_import, fileName)
        if (isAlreadyLoaded == 0):
            insert_train(fileNameFull)
            fileNameMoved=os.path.join(path_archive,fileName)
            os.replace(fileNameFull,fileNameMoved) 
        else:
            fileNameMoved=os.path.join(path_archive_duplicates,fileName)
            os.replace(fileNameFull,fileNameMoved)  




# Insert Extend Info
str_load=str_extend

path_import =path_local + str_import + str_load
path_archive=path_local + str_archive + str_load
path_archive_duplicates=path_local + str_archive_duplicates + str_load

for fileName in os.listdir(path_import):  
    if (fileName.endswith(".xls") or fileName.endswith(".xlsx")) :
        param=[fileName]
        isAlreadyLoaded= already_loaded(engine_stg, param)
        fileNameFull=os.path.join(path_import, fileName)
        if (isAlreadyLoaded == 0):
            insert_extend(fileNameFull)
            fileNameMoved=os.path.join(path_archive,fileName)
            os.replace(fileNameFull,fileNameMoved) 
        else:
            fileNameMoved=os.path.join(path_archive_duplicates,fileName)
            os.replace(fileNameFull,fileNameMoved)  


end = time.time()
print(end - start)

