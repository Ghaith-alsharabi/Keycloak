import pandas as pd
import os


# Install xlrd

class BasicInfo:
    """
    Reading basic info match excel and store the tables in data frames.
    The output is a list of those data frames.

    """

    def __init__(self, path):
        """
        Initialize BasicInfo object
        If path doesn't lead to a file return FileNotFoundError

        :param path: Path of the excel file
        """
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        self.path = path

    def excel_to_df(self):
        df_list = []

        # Read excel file using class ExcelFile
        xlx_basic_info = pd.ExcelFile(self.path)

        # Get names of the diff spreadsheets
        sps_names = xlx_basic_info.sheet_names
        # Read first spreadsheet ('Basic Info')
        df_info_match = pd.read_excel(xlx_basic_info, sheet_name=sps_names[0])

        # Set index Basic Info
        df_info_match.set_index('Basic Info', inplace=True)

        # Categories in rows so we transpose the table
        dft_info_match = df_info_match.transpose()

        # Reset index of rows
        dft_info_match.reset_index(drop=True, inplace=True)

        # Get match id
        match_id = dft_info_match.iloc[0]["Match ID"]

        # Get team id
        team_id = dft_info_match.iloc[0]["Exported team ID"]

        # Read second spreadsheet ('Players')
        df_info_players = pd.read_excel(xlx_basic_info, sheet_name=sps_names[1])
        df_info_players.reset_index(drop=True, inplace=True)

        df_list.append((str(match_id) + "/" + str(team_id) + "/basic_match", dft_info_match))
        df_list.append((str(match_id) + "/" + str(team_id) + "/basic_players", df_info_players))

        return df_list


class Train:
    """
    Reading training info excel and store the tables in data frames.
    The output is a list of those data frames.

    """

    def __init__(self, path):
        """
        Initialize TrainInfo object
        If path doesn't lead to a file return FileNotFoundError

        :param path: Path of the excel file
        """
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        self.path = path

    def excel_to_df(self):

        list_df = []

        # Same process with the others excels Training excel:
        xlx_train_info = pd.ExcelFile(self.path)
        sps_names = xlx_train_info.sheet_names

        # First spreadsheet training
        df_train = pd.read_excel(xlx_train_info, sheet_name=sps_names[0])
        col_train = df_train.columns

        # Get Training info table
        df_train_info = df_train.loc[:0, :]
        df_train_info.reset_index(drop=True, inplace=True)

        # Get training team info table
        df_train_team = df_train.loc[3:4, :]
        df_train_team = df_train_team[['trainingId', 'beginTime']]
        df_train_team.columns = df_train_team.iloc[0]
        df_train_team.drop(df_train_team.index[0], inplace=True)
        df_train_team.reset_index(drop=True, inplace=True)

        # Get training players info table
        df_train_player = df_train.iloc[7:, :]
        df_train_player = df_train_player.loc[:, col_train[:7]]
        df_train_player.columns = df_train_player.iloc[0]
        df_train_player.drop(df_train_player.index[0], inplace=True)
        df_train_player.reset_index(drop=True, inplace=True)

        # Train id
        train_id = df_train_info.iloc[0]["trainingId"]
        list_df.append((str(train_id) + "/train_info", df_train_info))
        list_df.append((str(train_id) + "/train_team", df_train_team))
        list_df.append((str(train_id) + "/train_player", df_train_player))

        # Rest of spreadsheets in training are Physical
        for i in range(1, len(sps_names)):
            df_train_physical = pd.read_excel(xlx_train_info, sheet_name=sps_names[i])

            # Since tables have flexible size, need to determinate divider
            player_id = df_train_physical["id"].fillna("0").tolist()
            div = [player_id.index(x) for x in player_id if not x.isdigit()][0]

            # Overall physical table
            df_physical = df_train_physical.iloc[:div - 3, :]

            # BPM_Avg table
            df_bpm_avg = df_train_physical.iloc[div + 1:, :len(df_physical.index)]
            df_bpm_avg.columns = player_id[:div - 3]
            df_bpm_avg = df_bpm_avg.transpose()
            df_bpm_avg.columns = range(len(df_bpm_avg.columns))
            df_bpm_avg.reset_index(level=0, inplace=True)
            df_bpm_avg.rename(columns={"index": "Player_id"}, inplace=True)

            list_df.append((str(train_id) + "/train_physical_A" + str(i), df_physical))
            list_df.append((str(train_id) + "/BPM_Avg_A" + str(i), df_bpm_avg))

        return list_df
