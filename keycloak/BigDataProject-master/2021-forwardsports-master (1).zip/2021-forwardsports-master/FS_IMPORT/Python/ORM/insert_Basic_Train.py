from Python.ORM.base import engine_stg
from Python.Read_excels.read_BasicInfo_TrainInfo import BasicInfo, Train
from Python.Cleaning.clean_BasicInfo_TrainInfo import clean_basic_info, clean_train_info


def insert_basic(path_basic_info):
    # Read Basic Info excel
    dfs_basic_info = BasicInfo(path_basic_info)

    # Clean the data frames of Basic Info
    dfs_basic_info_cleaned = clean_basic_info(dfs_basic_info.excel_to_df())

    # Accessing to the different dfs in Basic Info
    df_basic_match = dfs_basic_info_cleaned[0]
    df_basic_players = dfs_basic_info_cleaned[1]

    # Renaming the name of the columns of the dfs so it matches with the columns inside the
    # correspondent tables
    # Basic Match
    names_basic_match = ["Date", "Match_id", "Opponents", "Exp_team", "Team_id", "Time", "Duration", "N_players",
                         "Team_A", "Score_Team_A", "Team_B", "Score_Team_B"]

    df_basic_match[1].columns = names_basic_match

    # Adding Extracted_File column for future checking purposes
    df_basic_match[1]["Extracted_File"] = dfs_basic_info.path.split("\\")[-1]

    # Basic Info Players
    # Repeat the same procedure done with basic_info
    names_basic_players = ["Player_id", "Name", "Gender", "Birthday", "Weight", "Height", "Position", "N_shirt",
                           "Sub_on", "Sub_off",
                           "Time_played", "HHR_Max", "HR_Max", "HR_Min", "HR_Avg", "Rate_0_50", "Rate_50_60",
                           "Rate_60_70",
                           "Rate_70_80", "Rate_80_90", "Rate_90_100", "Time_Ratio_0_50", "Time_Ratio_50_60",
                           "Time_Ratio_60_70", "Time_Ratio_70_80", "Time_Ratio_80_90", "Time_Ratio_90_100",
                           "Physical_Load",
                           "Intensity", "VO2_Max", "Calories", "Speed_Max", "Dribble_Speed_Max", "Distance",
                           "Distance_perMin", "Walk_Distance", "Jog_Distance", "Low_Running_Distance",
                           "Medium_Running_Distance", "High_Running_Distance", "Sprint_Distance", "High_Runs",
                           "Sprints",
                           "Run_Avg", "Receives", "Passes", "Passes_Completed", "Passes_Completed_Perc",
                           "Passes_Forward",
                           "Passes_Completed_Forward", "Passes_Completed_Forward_Perc",
                           "Passes_Forward_Perc",
                           "Interceptions"]
    df_basic_players[1].columns = names_basic_players
    df_basic_players[1]["Extracted_File"] = dfs_basic_info.path.split("\\")[-1]
    df_basic_players[1]["Match_id"] = df_basic_players[0].split("/")[0]
    df_basic_players[1]["Team_id"] = df_basic_players[0].split("/")[1]

    # Establishing a connection to the database
    connection = engine_stg.connect()

    try:
        # Inserting the Basic Info dfs
        df_basic_match[1].to_sql(name="basic_match", con=connection, if_exists='append', index=False)
        df_basic_players[1].to_sql(name="basic_players", con=connection, if_exists='append', index=False)

    except ValueError as vx:
        print(vx)

    except Exception as ex:
        print(ex)

    else:
        print("Inserted data Basic Info: {" + dfs_basic_info.path.split("\\")[-1] + "}")
    finally:
        # Close connection after insert
        connection.close()


def insert_train(path_train_info):
    # Read Train Info excel
    dfs_train_info = Train(path_train_info)

    # Clean the data frames of Train Info
    dfs_train_info_cleaned = clean_train_info(dfs_train_info.excel_to_df())

    # Accessing to the different dfs in Train Info
    df_train_info = dfs_train_info_cleaned[0]
    df_train_team = dfs_train_info_cleaned[1]
    df_train_player = dfs_train_info_cleaned[2]
    df_train_physical = dfs_train_info_cleaned[3:len(dfs_train_info_cleaned):2]
    df_train_bpm = dfs_train_info_cleaned[4:len(dfs_train_info_cleaned):2]

    # Renaming the name of the columns of the dfs so it matches with the columns inside the
    # correspondent tables
    # Train Info
    names_train_info = ["Train_id", "Time_begin", "Time_end", "Time", "Court_Length", "Court_Width", "Anchor_Mode",
                        "Ball_Mode", "App_Version", "Algorithm_Version", "Log_Version"]

    df_train_info[1].columns = names_train_info

    # Adding Extracted_File column for future checking purposes
    df_train_info[1]["Extracted_File"] = dfs_train_info.path.split("\\")[-1]

    # Train Team
    names_train_team = ["Team_id", "team_Name"]

    df_train_team[1].columns = names_train_team
    df_train_team[1]["Extracted_File"] = dfs_train_info.path.split("\\")[-1]
    df_train_team[1]["Train_id"] = df_train_team[0].split("/")[0]

    # Train Player
    names_train_player = ["Player_id", "Name", "Number", "Height", "Weight", "HR_base", "HHR_Max"]

    df_train_player[1].columns = names_train_player
    df_train_player[1]["Extracted_File"] = dfs_train_info.path.split("\\")[-1]
    df_train_player[1]["Train_id"] = df_train_player[0].split("/")[0]

    # Train Physical
    names_train_physical = ["Player_id", "Name", "Duration", "Distance_Covered", "High_Speed_Distance",
                            "Sprint_Speed_Distance", "Calories",
                            "Exercise_Load", "HR_Max", "Speed_Max", "VO2_Max", "Acc_Low_Count", "Acc_Mid_Count",
                            "Acc_High_Count", "Dec_Low_Count", "Dec_Mid_Count", "Dec_High_Count", "Left_Turn_Low_Count",
                            "Left_Turn_Mid_Count", "Left_Turn_High_Count", "Right_Turn_Low_Count",
                            "Right_Turn_Mid_Count",
                            "Right_Turn_High_Count"]

    for physical in df_train_physical:
        physical[1].columns = names_train_physical
        physical[1]["Extracted_File"] = dfs_train_info.path.split("\\")[-1]
        physical[1]["id"] = physical[0].split("/")[1][-1]
        physical[1]["Train_id"] = physical[0].split("/")[0]

    # Train BPM Data
    for bpm in df_train_bpm:
        bpm[1]["Extracted_File"] = dfs_train_info.path.split("\\")[-1]
        bpm[1]["id"] = bpm[0].split("/")[1][-1]
        bpm[1]["Train_id"] = bpm[0].split("/")[0]

    # Establishing a connection to the database
    connection = engine_stg.connect()

    try:

        # Inserting Train Info dfs
        df_train_info[1].to_sql(name="train_info", con=connection, if_exists='append', index=False)
        df_train_team[1].to_sql(name="train_team", con=connection, if_exists='append', index=False)
        df_train_player[1].to_sql(name="train_players", con=connection, if_exists='append', index=False)
        for physical in df_train_physical:
            physical[1].to_sql(name="train_physical", con=connection, if_exists='append', index=False)
        for bpm in df_train_bpm:
            bpm[1].to_sql(name="train_bpm", con=connection, if_exists='append', index=False)

    except ValueError as vx:
        print(vx)

    except Exception as ex:
        print(ex)

    else:
        print("Inserted data Train Info: {" + dfs_train_info.path.split("\\")[-1] + "}")
    finally:
        # Close connection after insert
        connection.close()
