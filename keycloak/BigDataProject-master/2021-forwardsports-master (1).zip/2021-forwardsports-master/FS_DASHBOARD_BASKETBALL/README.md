# Forward Sports Basketball App

### Installation
```
Windows
$ git clone https://github.com/nilsleh/fsBasketballApp.git
$ cd fsBasketballApp
$ python -m venv myenv
$ .\myenv\Scripts\activate
$ pip install -r requirements.txt
$ flask run 
```

```
Mac
$ git clone https://github.com/nilsleh/fsBasketballApp.git
$ cd fsBasketballApp
$ python3 -m venv myenv
$ source myenv/bin/activate
$ pip3 install -r requirements.txt
$ flask run 
```

