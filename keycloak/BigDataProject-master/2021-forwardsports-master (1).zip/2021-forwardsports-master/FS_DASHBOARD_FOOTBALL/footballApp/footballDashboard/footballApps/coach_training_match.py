import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State, MATCH, ALL
import dash_table

import pandas as pd
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objs as go

from .database import database as db

def coach_training_match_layout():
    layout = html.Div(children=[
                            
    ]) # end training match tab

    return layout