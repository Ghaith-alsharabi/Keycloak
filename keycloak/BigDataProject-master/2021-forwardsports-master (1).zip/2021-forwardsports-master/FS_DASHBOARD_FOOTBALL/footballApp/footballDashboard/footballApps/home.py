import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
from . import commonmodules

#from app import app

def home_layout():
    layout = html.Div([
        commonmodules.get_header(),
        commonmodules.get_menu(),
        html.Br(),
        html.H3('This is home screen', style={"textAlign": "center"}),
    ])

    return layout