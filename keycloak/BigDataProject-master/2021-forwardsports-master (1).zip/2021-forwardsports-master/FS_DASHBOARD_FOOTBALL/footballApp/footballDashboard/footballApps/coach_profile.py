import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State, MATCH, ALL
import dash_table

import pandas as pd
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objs as go
import colorlover

from .database import database as db

def coach_profile_layout():
    my_team_name = 'AFCU9-1'
    player_id = "72264"

    # get the match_ids for the team 
    match_id_str, match_dates = db.latest_matches_per_team(my_team_name)

    last_five_df = db.match_performance_development(match_id_str)


    ##### function to update color heatmap for values #### 
    def discrete_background_color_bins(df, n_bins=5, columns='all'):
    
        bounds = [i * (1.0 / n_bins) for i in range(n_bins + 1)]
        if columns == 'all':
            if 'id' in df:
                df_numeric_columns = df.select_dtypes('number').drop(['id'], axis=1)
            else:
                df_numeric_columns = df.select_dtypes('number')
        else:
            df_numeric_columns = df[columns]
        df_max = df_numeric_columns.max().max()
        df_min = df_numeric_columns.min().min()
        ranges = [
            ((df_max - df_min) * i) + df_min
            for i in bounds
        ]
        styles = []
        legend = []
        for i in range(1, len(bounds)):
            min_bound = ranges[i - 1]
            max_bound = ranges[i]
            backgroundColor = colorlover.scales[str(n_bins)]['seq']['Blues'][i - 1]
            color = 'white' if i > len(bounds) / 2. else 'inherit'

            for column in df_numeric_columns:
                styles.append({
                    'if': {
                        'filter_query': (
                            '{{{column}}} >= {min_bound}' +
                            (' && {{{column}}} < {max_bound}' if (i < len(bounds) - 1) else '')
                        ).format(column=column, min_bound=min_bound, max_bound=max_bound),
                        'column_id': column
                    },
                    'backgroundColor': backgroundColor,
                    'color': color
                })
            legend.append(
                html.Div(style={'display': 'inline-block', 'width': '60px'}, children=[
                    html.Div(
                        style={
                            'backgroundColor': backgroundColor,
                            'borderLeft': '1px rgb(50, 50, 50) solid',
                            'height': '10px'
                        }
                    ),
                    html.Small(round(min_bound, 2), style={'paddingLeft': '2px'})
                ])
            )

        return (styles, html.Div(legend, style={'padding': '5px 0 5px 0'}))

    (styles_last_five, legend_last_five) = discrete_background_color_bins(last_five_df)

    #### custom legend with green red orange
    custom_legend = []
    custom_bounds = [0, 0.8, 1, 1.3]
    custom_bounds = ['<0.8', '0.8-1', '1-1.3', '>1.3']
    # custom colors blue, orange, green, red
    custom_colors = ['#042A66', '#ff9900', '#006C11', '#ff3333']
    for idx, backgroundColor in enumerate(custom_colors):
        custom_legend.append(
                    html.Div(style={'display': 'inline-block', 'width': '60px'}, children=[
                        html.Div(
                            style={
                                'backgroundColor': backgroundColor,
                                'borderLeft': '1px rgb(50, 50, 50) solid',
                                'height': '10px'
                            }
                        ),
                        html.Small(custom_bounds[idx], style={'paddingLeft': '2px'})
                    ])
                )


    #### matrix player fitness chart ####
    mean = last_five_df[last_five_df['Player ID']=='mean']
    mean.reset_index(inplace=True)
    mean_ima = mean.loc[0, 'Ball']
    mean_internal = mean.loc[0, 'Internal']
    player_fitness_matrix_plot = go.Figure(
        go.Scatter(
            x=last_five_df['Ball'], 
            y=last_five_df['Internal'], 
            mode='markers', 
            marker_size=10, 
            customdata=np.stack((last_five_df['Player ID'], last_five_df['Ball'], last_five_df['Internal']),axis=-1),
            hovertemplate="<br>Player:%{customdata[0]}<br>Ball:%{customdata[1]}<br>Internal:%{customdata[2]}",
        )
    )

    # vertical mean for IMA
    player_fitness_matrix_plot.add_shape(
        dict(
            type="line",
            x0=mean_ima,
            y0=0,
            x1=mean_ima,
            y1=last_five_df['Internal'].max(),
            line=dict(
                color="RoyalBlue",
                width=3
            )
        )
    )
    # horizontal mean for Internal
    player_fitness_matrix_plot.add_shape(
        dict(
            type="line",
            x0=0,
            y0=mean_internal,
            x1=last_five_df['Ball'].max(),
            y1=mean_internal,
            line=dict(
                color="RoyalBlue",
                width=3
            )
        )
    )
    player_fitness_matrix_plot.update_layout(
        template='plotly_white',
        height=900,
        xaxis_title="Ball",
        yaxis_title="Exercise Load",
        font= dict(
            size=18,
        )
    )

    layout = html.Div(children=[
        
            html.H3(" Flip de Bruijn", style={
                                            'textAlign': 'center',
                                        }),

                        dbc.Row([
                            dbc.Col(
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H3("Team Picture", style={
                                            'textAlign': 'center'
                                        }),
                                        html.Img(src='/assets/nederland.png', style={'textAlign': 'center', 'height': 250, 'width': 400,}),
                                    ])
                                ]), width=5,  
                            ),
                            dbc.Col(
                                dbc.Card([
                                    dbc.CardBody([
                                        html.H3("Coach Info", style={
                                            'textAlign': 'center',
                                        }),
                                        html.H6("Teams:"),
                                        html.H6("Age:"),
                                    ])
                                ]), width=5,
                            ),
                        ],
                        justify="center",
                        ),
                        html.Div([
                            html.H3("Match Performance Development"),
                            html.Div(custom_legend, style={'textAlign': 'center'}),
                            html.Div(children=[
                                dash_table.DataTable(
                                    id='match-performance-data',
                                    columns = [
                                        {"name": i, "id": i, "selectable": True} for i in last_five_df.columns
                                    ],
                                    data = last_five_df.to_dict('records'),
                                    sort_action='native',
                                    #fixed_rows={'headers': True, 'data': 0},
                                    style_table={
                                        #'minWidth': '100%',
                                        'minWidth': '100%',
                                        'height': '500px',
                                        'overflowY': 'auto',
                                    },
                                    style_cell={
                                        'textAlign': 'center',
                                        'minWidth': '80px', 'width': '100px', 'maxWidth': '120px',
                                    },
                                    style_header={
                                        'fontWeight': 'bold',
                                        # 'minWidth': '80px', 'width': '100px', 'maxWidth': '120px',
                                    },
                                    #style_data_conditional=styles_last_five
                                    style_data_conditional=(
                                        [
                                        {# if value > 1.3 RED
                                            'if': {
                                                'filter_query': "{{{}}} > 1.3".format(col),
                                                'column_id': col
                                            },
                                            'backgroundColor': '#ff3333',
                                            'color': 'white'
                                        } for col in list(last_five_df.select_dtypes(include=[np.number]).columns.values)
                                        ] +
                                        [
                                        {# if value between 1 and 1.3 green
                                            'if': {
                                                'filter_query': '{{{}}} >= 1 && {{{}}} <= 1.3'.format(col, col),
                                                'column_id': col
                                            },
                                            'backgroundColor': '#006C11',
                                            'color': 'white'
                                        } for col in list(last_five_df.select_dtypes(include=[np.number]).columns.values)
                                        ] + 
                                        [
                                        { # if value between 0.8 and 1 orange
                                            'if': {
                                                'filter_query': '{{{}}} >= 0.8 && {{{}}} < 1'.format(col, col),
                                                'column_id': col
                                            },
                                            'backgroundColor': '#ff9900',
                                            'color': 'white'
                                        } for col in list(last_five_df.select_dtypes(include=[np.number]).columns.values)
                                        ] +
                                        [
                                        {# if value < 0.8
                                            'if': {
                                                'filter_query': "{{{}}}<0.8".format(col),
                                                'column_id': col
                                            },
                                            'backgroundColor': '#042A66',
                                            'color': 'white'
                                        } for col in list(last_five_df.select_dtypes(include=[np.number]).columns.values)
                                        ] +
                                        # highlight the mean row
                                        [{
                                            'if': {
                                                'column_id': 'Player ID',
                                                'filter_query': "{Player ID} = 'mean'"
                                            },
                                            'backgroundColor': '#bfbfbf',
                                            'color': 'black'
                                        }]
                                    
                                    )
                                    

                                ),
                            ],style={'width':'90%','margin-left': 'auto', 'margin-right': 'auto'})  
                        ], style={'textAlign':'center'}),

            html.Div([
                            html.H3("Player Performance Development"),
                            html.Div(legend_last_five, style={'textAlign': 'center'}),
                            html.Div(children=[
                                dash_table.DataTable(
                                    id='performance-development-data',
                                    columns = [
                                        {"name": i, "id": i, "selectable": True} for i in last_five_df.columns
                                    ],
                                    data = last_five_df.to_dict('records'),
                                    sort_action='native',
                                    #fixed_rows={'headers': True, 'data': 0},
                                    style_table={
                                        #'minWidth': '100%',
                                        'minWidth': '100%',
                                        'height': '500px',
                                        'overflowY': 'auto',
                                    },
                                    style_cell={
                                        'textAlign': 'center',
                                        'minWidth': '80px', 'width': '100px', 'maxWidth': '120px',
                                    },
                                    style_header={
                                        'fontWeight': 'bold',
                                        # 'minWidth': '80px', 'width': '100px', 'maxWidth': '120px',
                                    },
                                    style_data_conditional=(styles_last_five + 
                                        # highlight the mean row
                                        [{
                                            'if': {
                                                'column_id': 'Player ID',
                                                'filter_query': "{Player ID} = 'mean'"
                                            },
                                            'backgroundColor': '#bfbfbf',
                                            'color': 'black'
                                        }]
                                    )

                                ),
                            ],style={'width':'90%','margin-left': 'auto', 'margin-right': 'auto'}),  
                        html.Div([
                            html.H3("Player Fitness Performance"),
                            dcc.Graph(
                                id='matrix-player-selection',
                                figure=player_fitness_matrix_plot
                            ),
                        ], style={'textAlign': 'center'}),
                        ], style={'textAlign':'center'}),
    ])

    return layout