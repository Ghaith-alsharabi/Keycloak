import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_table
import plotly.graph_objs as go
from plotly.subplots import make_subplots

#from apps import commonmodules
from .database import database as db


#from app import app
import numpy as np
import pandas as pd


def player_my_profile_layout():

    # call the callbacks
    #player_my_profile_callbacks():


    player_number = 11
    team = "AFCU9-1"
    player_id = "72264"


    categories = ['imaLeftMid', 'imaLeftHigh', 'imaRightMid', 'imaRightHigh',\
                'imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh', 'distanceCovered']

    latest_matches, matchDates = db.latest_matches_per_team(team)
    external_df, internal_df, ball_df, performance_df, stamina_AC,gauge_val_dict, trend_df, internal_fit, external_fit, ball_fit = db.latest_matches_per_player(player_id, latest_matches)


    # radar chart externalLoad
    ext_cat = external_df.columns

    external_radar = go.Figure()

    external_radar.add_trace(go.Scatterpolar(
        r=external_df.loc['latest', external_df.columns != 'SumE'],
        theta=ext_cat,
        fill='toself',
        name='Latest Game',
        line_color = 'orange'
    ))

    external_radar.add_trace(go.Scatterpolar(
        r=external_df.loc['meanLast5', external_df.columns!= 'SumE'],
        theta=ext_cat,
        fill='toself',
        name='Average over last 5 games',
        line_color = 'blue'
    ))

    external_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[external_df.min(), external_df.max()]
            )),
        showlegend=False,
        template='seaborn',
        margin=dict(t=10, b=10)
    )

    # radarChart internalLoad
    int_cat = internal_df.columns

    internal_radar = go.Figure()

    internal_radar.add_trace(go.Scatterpolar(
        r=internal_df.loc['latest', internal_df.columns!= 'SumI'],
        theta=int_cat,
        fill='toself',
        name='Latest Game',
        line_color = 'orange'
    ))

    internal_radar.add_trace(go.Scatterpolar(
        r=internal_df.loc['meanLast5', internal_df.columns != 'SumI'],
        theta=int_cat,
        fill='toself',
        name='Average over last 5 games',
        line_color = 'blue'
    ))

    internal_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[internal_df.min(), internal_df.max()]
            )),
        showlegend=False,
        template='seaborn',
        margin=dict(t=10, b=10)
    )

    # radar chart Ball Data
    ball_cat = ball_df.columns

    ball_radar = go.Figure()

    ball_radar.add_trace(go.Scatterpolar(
        r=ball_df.loc['latest', ball_df.columns!= 'SumB'],
        theta=ball_cat,
        fill='toself',
        name='Latest Game',
        line_color = 'orange'
    ))

    ball_radar.add_trace(go.Scatterpolar(
        r=ball_df.loc['meanLast5', ball_df.columns!= 'SumB'],
        theta=ball_cat,
        fill='toself',
        name='Average over last 5 games',
        line_color = 'blue'
    ))

    ball_radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[ball_df.min(), ball_df.max()]
            )),
        showlegend=False,
        template='seaborn',
        margin=dict(t=10, b=10)
    )
        

    external_gauge = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=gauge_val_dict['external'],
            domain={'x': [0,1], 'y':[0,1]},
            gauge={
                'axis': {'range': [None, 2], 'tickvals': [0, 0.95, 1.05, 2]},
                'bar': {'color': "black"},
                'borderwidth': 1,
                'bordercolor': 'gray',
                
                'steps': [
                    {'range': [0, 0.95], 'color': 'red'},
                    {'range': [0.95, 1.05], 'color': 'orange'},
                    {'range': [1.05, 2], 'color': 'green'},
                ],
            }
        ),
        go.Layout(
            height=400,
            #margin=dict(t=50, b=50),
            template='seaborn'
        ),
    )


    internal_gauge = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=gauge_val_dict['internal'],
            domain={'x': [0,1], 'y':[0,1]},
            gauge={
                'axis': {'range': [None, 2], 'tickvals': [0, 0.8, 1.0, 1.3 ,2]},
                'bar': {'color': "black"},
                'borderwidth': 1,
                'bordercolor': 'gray',
                
                'steps': [
                    {'range': [0, 0.8], 'color': 'blue'},
                    {'range': [0.8, 1.0], 'color': 'orange'},
                    {'range': [1.0, 1.3], 'color': 'green'},
                    {'range': [1.3, 2], 'color': 'red'},
                ],
            }
        ),
        go.Layout(
            height=400,
            #margin=dict(t=50, b=50),
            template='seaborn'
        ),
    )

    ball_avg = stamina_AC.loc['meanLast5', 'touches']
    ball_last = stamina_AC.loc['Latest', 'touches']

    ball_gauge = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=gauge_val_dict['ball'],
            domain={'x': [0,1], 'y':[0,1]},
            gauge={
                'axis': {'range': [None, 2], 'tickvals': [0, 0.95, 1.05, 2]},
                'bar': {'color': "black"},
                'borderwidth': 1,
                'bordercolor': 'gray',
                
                'steps': [
                    {'range': [0, 0.95], 'color': 'red'},
                    {'range': [0.95, 1.05], 'color': 'orange'},
                    {'range': [1.05, 2], 'color': 'green'},
                ],
            }
        ),
        go.Layout(
            height=400,
            #margin=dict(t=50, b=50),
            template='seaborn' 
        ),
    )

    performance_trend_chart = make_subplots(rows=3, cols=1, shared_xaxes=True)

    performance_trend_chart.add_trace(go.Scatter(x=trend_df['matchId'], y=trend_df['exerciseLoad'],
                mode='lines+markers', name='Internal'), row=1, col=1)

    performance_trend_chart.add_trace(go.Scatter(x=trend_df['matchId'], y=trend_df['imaSum'],
                mode='lines+markers', name='External'), row=2, col=1)

    performance_trend_chart.add_trace(go.Scatter(x=trend_df['matchId'], y=trend_df['ballSum'],
                mode='lines+markers', name='Ball'), row=3, col=1)

    performance_trend_chart.update_layout(
        template='seaborn',
        height=750,
        hovermode='x'
    )

    layout = html.Div(children=[
        html.H3(str(player_number) + " Flip de Bruijn", style={
            'textAlign': 'center',
        }),
        html.Div([
            html.Div([
                html.H3("Profile Picture", style={
                    'textAlign': 'center',
                }),
                html.Img(src='footballDashboard/assets/img/flip.png',
                        style={'textAlign': 'center'}),
            ], style={'display': 'inline-block', 'width': '49%', 'border-style': 'solid', 'border-color': '#7A7D7B', 'border-radius': '8px', 'border-width': '1px', 'vertical-align': 'top'},),

            html.Div([
                html.H3("Player Info", style={
                    'textAlign': 'center',
                }),
                html.H6("Position: Forward"),
                html.H6("Height: 190cm"),
                html.H6("Age:20"),
            ], style={'display': 'inline-block', 'width': '49%', 'border-style': 'solid', 'border-color': '#7A7D7B', 'border-radius': '8px', 'border-width': '1px', 'vertical-align': 'top'})
        ]),

        html.Div([
            html.H3("Match Performance Development", style={
                'textAlign': 'center',
            }),
            html.Div([
                html.Div([
                    html.H6("Internal", style={
                        'textAlign': 'center'}),
                    dcc.Graph(
                        id='gauge-internal-player',
                        figure=internal_gauge
                    ),
                    html.Div([
                        dcc.Graph(
                            id='radar-internal-player',
                            figure=internal_radar
                        ),
                    ], style={'margin-top': '10px', 'margin-bottom': '10px'}),

                ], style={'width': '33%', 'display': 'inline-block'}),
                html.Div([
                    html.H6("External", style={
                        'textAlign': 'center'}),
                    dcc.Graph(
                        id='gauge-external-player',
                        figure=external_gauge
                    ),
                    dcc.Graph(
                        id='radar-external-player',
                        figure=external_radar

                    ),
                ], style={'width': '33%', 'display': 'inline-block'}),

                html.Div([
                    html.H6("Ball", style={
                        'textAlign': 'center'}),
                    dcc.Graph(
                        id='gauge-ball-player',
                        figure=ball_gauge
                    ),
                    dcc.Graph(
                        id='radar-ball-player',
                        figure=ball_radar
                    )
                ], style={'width': '33%', 'display': 'inline-block'})
            ]),

        ], style={'margin-bottom': '50px'}),
        html.Div([
            html.H3("Seasonal Development", style={
                'textAlign': 'center',
            }),
            dcc.Graph(
                id='season-development-player',
                figure=performance_trend_chart
            ),
        ], style={'margin-top': '50px'}),

    ])

    return layout