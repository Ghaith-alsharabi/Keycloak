![Forward Football](Schema/ForwardFootball_logo.PNG)

# Database for forward football

> The aim of this project was to build an accessible database in python for a certain format of spreadsheets.


## Installation

- Requirements:
```shell
$ certifi==2020.4.5.1
$ numpy==1.18.3
$ pandas==1.0.3
$ PyMySQL==0.9.3
$ python-dateutil==2.8.1
$ pytz==2019.3
$ six==1.14.0
$ SQLAlchemy==1.3.16
$ wincertstore==0.2
$ xlrd==1.2.0
```

### Set up:

- Define engine in Python.ORM.base.py:
![Recordit GIF](http://g.recordit.co/9ewrh1Jwtm.gif)

- Define paths of the excel files in Python.Examples.insert_data.py:
![Recordit GIF](http://g.recordit.co/sk2XVM15XG.gif)

- Run Python.Examples.insert_data.py

## License

[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](http://badges.mit-license.org)

- **[MIT license](http://opensource.org/licenses/mit-license.php)**




