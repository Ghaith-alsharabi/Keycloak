from Python.ORM.db_BasicInfo import BasicMatch, BasicPlayers
from Python.ORM.db_TrainInfo import TrainInfo, TrainTeam, TrainPhysical, TrainBPM, TrainPlayers
from Python.ORM.db_ExtndInfo import ExtendIma, ExtendCoordBall, ExtendCoordPlayers, ExtendEventPass, ExtendEventShot, \
    ExtendEventTackle, ExtendIntervals, ExtendMatch, ExtendPlayers
from sqlalchemy import Column, String, Integer
from Python.ORM.base import Stg_Base


class BasicMatchStg(Stg_Base, BasicMatch):
    __tablename__ = 'basic_match'

    Team_A = Column(String(255))
    Score_Team_A = Column(Integer)
    Team_B = Column(String(255))
    Score_Team_B = Column(Integer)


class BasicPlayersStg(Stg_Base, BasicPlayers):
    __tablename__ = 'basic_players'


class TrainInfoStg(Stg_Base, TrainInfo):
    __tablename__ = "train_info"


class TrainTeamStg(Stg_Base, TrainTeam):
    __tablename__ = "train_team"


class TrainPlayersStg(Stg_Base, TrainPlayers):
    __tablename__ = "train_players"


class TrainPhysicalStg(Stg_Base, TrainPhysical):
    __tablename__ = "train_physical"


class TrainBPMStg(Stg_Base, TrainBPM):
    __tablename__ = "train_bpm"


class ExtendMatchStg(Stg_Base, ExtendMatch):
    __tablename__ = "extend_match"


class ExtendPlayersStg(Stg_Base, ExtendPlayers):
    __tablename__ = "extend_players"


class ExtendCoordBallStg(Stg_Base, ExtendCoordBall):
    __tablename__ = "extend_coordinates_ball"

    pos_X = Column(Integer, server_default="0")
    pos_Y = Column(Integer, server_default="0")


class ExtendCoordPlayersStg(Stg_Base, ExtendCoordPlayers):
    __tablename__ = "extend_coordinates_players"

    pos_X = Column(Integer, server_default="0")
    pos_Y = Column(Integer, server_default="0")


class ExtendIntervalsStg(Stg_Base, ExtendIntervals):
    __tablename__ = "extend_intervals"


class ExtendEventPassStg(Stg_Base, ExtendEventPass):
    __tablename__ = "extend_events_pass"


class ExtendEventShotStg(Stg_Base, ExtendEventShot):
    __tablename__ = "extend_events_shot"


class ExtendEventTackleStg(Stg_Base, ExtendEventTackle):
    __tablename__ = "extend_events_tackle"


class ExtendImaStg(Stg_Base, ExtendIma):
    __tablename__ = "extend_ima"
