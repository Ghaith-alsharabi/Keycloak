import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State, MATCH, ALL
import dash_table

import pandas as pd
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objs as go

from .database import database as db

def coach_tactical_analysis_layout(football_app):

    my_team_name = 'AFCU9-1'
    player_id = "72264"


    internal_parameters = ['exerciseLoad', 'maxVO2', 'runningDistance']
    external_parameters = ['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',
                        'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh']
    ball_parameters = ['touches', 'passes', 'shots', 'tackles']

    possible_team_matches = db.teams_and_matches(my_team_name)

    possible_match_players = db.matches_and_players(possible_team_matches[0])

    layout = html.Div(children=[
        # wrap this in html details container
        html.Details(children=[
            html.Summary("Match and Parameter Selection"),

            # parameter selection
            html.Div(id='parameter-selection-coach', children=[
                html.Div([
                    html.H6('Internal Parameters', style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='internal-select-coach',
                        options=[{'label': i, 'value': i}
                                for i in internal_parameters],
                        value=internal_parameters[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '49%', }),
                html.Div([
                    html.H6('External Parameters', style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='external-select-coach',
                        options=[{'label': i, 'value': i}
                                for i in external_parameters],
                        value=external_parameters[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '49%', }),
            ], style={'padding-top': '10px', 'margin-bottom': '10px'}),

            html.Div(id='match-selections-coach', children=[
                html.Div(children=[
                    html.H5("Select Match", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-select-tactical-coach-left',
                        options=[{'label': i, 'value': i}
                                for i in possible_team_matches],
                        value=possible_team_matches[0],
                        multi=False,
                    ),
                ], style={'display': 'inline-block', 'width': '49%'}),

                html.Div(children=[
                    html.H5("Select Match", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-select-tactical-coach-right',
                        options=[{'label': i, 'value': i}
                                for i in possible_team_matches],
                        value=possible_team_matches[0],
                        multi=False,
                    ),
                ], style={'display': 'inline-block', 'width': '49%'}),
            ]),

        ]),
        html.Details(children=[
            html.Summary("Match Modifications"),
            html.Div([
                html.Div([
                    html.Button('First Half', id='first-half-left',
                                n_clicks=0, style={'display': 'inline-block'}),
                    html.Button('Second Half', id='second-half-left',
                                n_clicks=0, style={'display': 'inline-block'}),
                ], style={'textAlign': 'center', 'margin-top': '5px', 'margin-bottom': '5px'}),

                dcc.RangeSlider(
                    id='time-slider-pitch-left-coach',
                    min=0,
                    max=45,
                    step=None,
                    marks={
                        0: "0'",
                        5: "5'",
                        10: "10'",
                        15: "15'",
                        20: "20'",
                        25: "25'",
                        30: "30'",
                        35: "35'",
                        40: "40'",
                        45: "45'"
                    },
                    pushable=5,
                    value=[0, 45],
                ),

                dcc.Dropdown(
                    id='player-select-left-pitch-coach',
                    #options=[{'label': i, 'value': i} for i in xy_players],
                    options=[{'label': i, 'value': i}
                            for i in possible_match_players],
                    value=[possible_match_players[0]],
                    multi=True
                ),
            ], style={'display': 'inline-block', 'width': '49%'},),

            html.Div([
                html.Div([
                    html.Button('First Half', id='first-half-right',
                                n_clicks=0, style={'display': 'inline-block'}),
                    html.Button('Second Half', id='second-half-right',
                                n_clicks=0, style={'display': 'inline-block'}),
                ], style={'textAlign': 'center', 'margin-top': '5px', 'margin-bottom': '5px'}),

                dcc.RangeSlider(
                    id='time-slider-pitch-right-coach',
                    min=0,
                    max=45,
                    step=None,
                    marks={
                        0: "0'",
                        5: "5'",
                        10: "10'",
                        15: "15'",
                        20: "20'",
                        25: "25'",
                        30: "30'",
                        35: "35'",
                        40: "40'",
                        45: "45'"
                    },
                    pushable=5,
                    value=[0, 45],
                ),

                dcc.Dropdown(
                    id='player-select-right-pitch-coach',
                    # options=[{'label': i, 'value': i} for i in xy_players],
                    # value=[xy_players[0]],
                    options=[{'label': i, 'value': i}
                            for i in possible_match_players],
                    value=[possible_match_players[0]],
                    multi=True,
                ),
            ], style={'display': 'inline-block', 'width': '49%'},)
        ]),
        ####
        html.Div([
            html.Div([

                html.Div(
                    dash_table.DataTable(
                        id='datatable-left-pitch-coach',
                        style_data_conditional=[
                            {
                                'if': {'row_index': 'odd'},
                                'backgroundColor': 'rgb(248, 248, 248)'
                            }
                        ],
                        sort_action="native",
                        style_cell={'textAlign': 'center'},
                        style_header={
                            'fontWeight': 'bold'
                        },
                        style_table={
                            'table-layout': 'fixed',
                                            'width': '90%',
                        },
                    ),
                ),

                dcc.Graph(
                    id="football-pitch-left-coach"
                ),

                dcc.Graph(
                    id="football-heatmap-left-coach",
                ),

            ], style={'display': 'inline-block', 'width': '45%', 'margin-right': '5px', 'margin-top': '10px', 'vertical-align': 'top'}),

            # to select first or seconds half
            html.Div([

                html.Div(
                    dash_table.DataTable(
                        id='datatable-right-pitch-coach',
                        style_data_conditional=[
                            {
                                'if': {'row_index': 'odd'},
                                'backgroundColor': 'rgb(248, 248, 248)'
                            }
                        ],
                        sort_action="native",
                        style_cell={'textAlign': 'center'},
                        style_header={
                            'fontWeight': 'bold'
                        },
                        style_table={
                            'table-layout': 'fixed',
                                            'width': '90%',
                        }
                    ),
                ),

                dcc.Graph(
                    id="football-pitch-right-coach",
                    config={
                        'displayModeBar': False
                    },
                ),


                dcc.Graph(
                    id="football-heatmap-right-coach",
                ),


            ], style={'display': 'inline-block', 'width': '49%', 'margin-left': '5px', 'margin-top': '10px', 'vertical-align': 'top'}),

        ], style={'display': 'flex', 'justify-content': 'center', 'align-items': 'center'}),
    ])

    # initiate the callbacks
    init_coach_tactical_analysis_callbacks(football_app)

    return layout

#######################################

################ CALLBACKS #############

########################################

def init_coach_tactical_analysis_callbacks(football_app):

    ### callback for left pitch ###
    @football_app.callback(
        [Output('football-pitch-left-coach', 'figure'),
        Output('football-heatmap-left-coach', 'figure')],
        [Input('time-slider-pitch-left-coach', 'value'),
        Input('player-select-left-pitch-coach', 'value'),
        Input('football-pitch-left-coach', 'clickData'),
        Input('match-select-tactical-coach-left', 'value')]
    )
    def update_pitch_left_coach(time, players, clickData, matchId):
        fig, fig2 = update_pitch_coach(time, players, clickData, matchId)
        return fig, fig2


    # callback for left table underneath the pitch
    @football_app.callback(
        [Output('datatable-left-pitch-coach', 'columns'),
        Output('datatable-left-pitch-coach', 'data')],
        [Input('football-pitch-left-coach', 'clickData'),
        Input('internal-select-coach', 'value'),
        Input('external-select-coach', 'value'),
        #Input('ball-select-coach', 'value'),
        Input('time-slider-pitch-left-coach', 'value'),
        Input('player-select-left-pitch-coach', 'value'),
        Input('match-select-tactical-coach-left', 'value')]
    )
    def update_left_pitch_table(clickData, internal_param, external_param, time, players, matchId):
        columns, data = update_pitch_table(
            clickData, internal_param, external_param, time, players, matchId)
        return columns, data

    # callback for right pitch


    @football_app.callback(
        [Output('football-pitch-right-coach', 'figure'),
        Output('football-heatmap-right-coach', 'figure')],
        [Input('time-slider-pitch-right-coach', 'value'),
        Input('player-select-right-pitch-coach', 'value'),
        Input('football-pitch-right-coach', 'clickData'),
        Input('match-select-tactical-coach-right', 'value')]
    )
    def update_pitch_right_coach(time, players, clickData, matchId):
        fig, fig2 = update_pitch_coach(time, players, clickData, matchId)
        return fig, fig2


    # callback for right table underneath the pitch
    @football_app.callback(
        [Output('datatable-right-pitch-coach', 'columns'),
        Output('datatable-right-pitch-coach', 'data')],
        [Input('football-pitch-right-coach', 'clickData'),
        Input('internal-select-coach', 'value'),
        Input('external-select-coach', 'value'),
        #Input('ball-select-coach', 'value'),
        Input('time-slider-pitch-right-coach', 'value'),
        Input('player-select-right-pitch-coach', 'value'),
        Input('match-select-tactical-coach-right', 'value')]
    )
    def update_right_pitch_table(clickData, internal_param, external_param, time, players, matchId):
        columns, data = update_pitch_table(
            clickData, internal_param, external_param, time, players, matchId)
        return columns, data


    def update_pitch_table(clickData, internal_param, external_param, time, players, matchId):
        # if only one is selected, put it in list format
        if isinstance(internal_param, str):
            internal = [internal_param]
        elif isinstance(internal_param, list) and not internal_param:
            internal = []
        else:
            internal = internal_param

        if isinstance(external_param, str):
            external = [external_param]
        elif isinstance(external_param, list) and not external_param:
            external = []
        else:
            external = external_param

        # get list to check types in database
        ima, intensity = ima_and_intensity(external)

        # put players, ima and intensity in correct format
        set_of_players = ["'" + m for m in players]
        set_of_players = [m + "'" for m in set_of_players]
        set_of_players_str = ','.join(set_of_players)

        set_of_ima = ["'" + m for m in ima]
        set_of_ima = [m + "'" for m in set_of_ima]
        set_of_ima_str = ','.join(set_of_ima)

        set_of_intensity = ["'" + m for m in intensity]
        set_of_intensity = [m + "'" for m in set_of_intensity]
        set_of_intensity_str = ','.join(set_of_intensity)

        # database call
        ima_event_df = db.combine_ima_events(
            matchId, set_of_players_str, time, set_of_ima_str, set_of_intensity_str)

        interval_df = db.combine_interval_events(
            matchId, set_of_players_str, time, internal)

        # merge the two dataframes by player id
        full_event_df = pd.merge(ima_event_df, interval_df,
                                how='left', left_on='playerId', right_on='playerId')

        # get ball events
        time_df, pitch_size, completion_rate = db.combine_ball_event_data(
            matchId, set_of_players_str, time)
        ball_df = time_df.groupby(['playerId', 'Type']).size().reset_index()
        ball_df.columns = ['playerId', 'Type', 'count']
        ball_df = ball_df.pivot(
            index='playerId', columns='Type', values='count').reset_index()

        # add ball events to full table
        full_event_df = pd.merge(
            full_event_df, ball_df, how='left', left_on='playerId', right_on='playerId')

        # if the df has at least 2 entries add a sum row
        if len(full_event_df) > 1:
            # add the sum row
            full_event_df.loc['Sum'] = full_event_df.sum()
            full_event_df.loc['Sum', 'playerId'] = 'Sum'

        # round the values
        full_event_df = full_event_df.round(2)
        # return the data as a dash data table
        columns = [
            {"name": i, "id": i, "selectable": True} for i in full_event_df.columns.tolist()
        ]
        data = full_event_df.to_dict('records')

        return columns, data


    def ima_and_intensity(param):
        ima = []
        intensity = []
        for p in param:
            if 'Acc' in p:
                ima.append('ACC')
            if 'Dec' in p:
                ima.append('DEC')
            if 'Righ' in p:
                ima.append('RIGH_TURN')
            if 'Left' in p:
                ima.append('LEFT_TURN')

            if 'Low' in p:
                intensity.append('LOW')
            if 'Mid' in p:
                intensity.append('MID')
            if 'High' in p:
                intensity.append('HIGH')

        return ima, intensity


    def update_pitch_coach(time, players, clickData, matchId):

        # get players in correct format to query from database
        set_of_players = ["'" + m for m in players]
        set_of_players = [m + "'" for m in set_of_players]
        set_of_players_str = ','.join(set_of_players)

        # time_df = xy_df[xy_df['minute'].between(begin, end)]

        time_df, pitch_size, completion_rate = db.combine_ball_event_data(
            matchId, set_of_players_str, time)

        # print(time_df)
        pitch_size = 'SIX'

        # get correct field size
        # 6 V 6 #
        # if max_x_position < 45 and max_y_position < 35:
        if pitch_size == "SIX":
            pitch_x = 42.5
            pitch_y = 30
            penalty_x = 7
            penalty_y = pitch_y
            mid_circle_radius = 4
        # 8 V 8 #
        # elif max_x_position < 70 and max_y_position < 50:
        elif pitch_size == "EIGTH":
            pitch_x = 64
            pitch_y = 42.5
            penalty_x = 12
            penalty_y = pitch_y
            mid_circle_radius = 6
        # 11 V 11 #
        else:
            pitch_x = 100
            pitch_y = 64
            penalty_x = 16
            penalty_y = 23
            mid_circle_radius = 10

        # create football pitch
        fig = go.Figure()

        # Set axes properties / This is a vertical football pitch
        # fig.update_xaxes(range=[0, pitch_y], zeroline=False)
        # fig.update_yaxes(range=[0, pitch_x])

        # add pitch outline
        fig.add_shape(
            # outline pitch
            type="rect",
            x0=0,
            y0=0,
            x1=pitch_x,
            y1=pitch_y,
            line=dict(
                color="black",
            ),
        )

        # add midline
        fig.add_shape(
            type='line',
            x0=0,
            y0=pitch_y/2,
            x1=pitch_x,
            y1=pitch_y/2
        )

        # add mid circle
        fig.add_shape(
            type='circle',
            xref="x",
            yref='y',
            x0=(pitch_x/2)-mid_circle_radius,
            y0=(pitch_y/2)-mid_circle_radius,
            x1=(pitch_x/2)+mid_circle_radius,
            y1=(pitch_y/2)+mid_circle_radius
        )

        # add bottom penalty area
        fig.add_shape(
            type='rect',
            x0=(pitch_x/2)-(penalty_x/2),
            y0=0,
            x1=(pitch_x/2)+(penalty_x/2),
            y1=penalty_y
        )

        fig.add_shape(
            type='rect',
            x0=(pitch_x/2)-(penalty_x/2),
            y0=pitch_y - penalty_y,
            x1=(pitch_x/2)+(penalty_x/2),
            y1=pitch_y
        )

        # add invisible boxes that allow the hovering
        n_boxes_x = 6
        n_boxes_y = 3
        box_size_x = pitch_x / n_boxes_x
        box_size_y = pitch_y / n_boxes_y
        zone_counter = 0

        gridx = np.linspace(0, pitch_x, 6)
        gridy = np.linspace(0, pitch_y, 3)
        # dictionaries to keep track of the box coordinates so data can be retrieved
        box_x_dict = {}
        box_y_dict = {}

        for i in range(n_boxes_x):
            #zone_i = i
            for j in range(n_boxes_y):
                zone_counter += 1
                x_data = [0 + i * box_size_x, 0 + i * box_size_x,
                        i * box_size_x + box_size_x, i * box_size_x + box_size_x,
                        0 + i * box_size_x]
                y_data = [0 + j * box_size_y, j * box_size_y + box_size_y,
                        j * box_size_y + box_size_y, 0 + j * box_size_y,
                        0 + j * box_size_y]
                fig.add_trace(
                    go.Scatter(
                        x=x_data,
                        y=y_data,
                        fill='toself',
                        name="Zone" + str(zone_counter),
                        fillcolor='rgba(255,255,255,1)',
                        line=dict(color='rgba(224,224,224,.8)', width=2,
                                dash='dash'),
                        showlegend=False
                    )
                )

                # add data to dictionary
                box_x_dict[zone_counter-1] = x_data
                box_y_dict[zone_counter-1] = y_data

        event_types = time_df['Type'].unique().tolist()
        # think about taking out touches
        for e in event_types:
            if e == 'pass':
                marker_color = 'blue'
            elif e == 'shot':
                marker_color = 'red'
            elif e == 'tackle':
                marker_color = 'yellow'
            elif e == 'touch':
                marker_color = 'black'
            else:
                marker_color = 'green'

            plot_df = time_df[time_df['Type'] == e]
            fig.add_trace(
                go.Scatter(
                    x=plot_df['posX'],
                    y=plot_df['posY'],
                    name=e,
                    mode='markers',
                    marker=dict(
                        color=marker_color,
                        size=10,
                    ),
                    # text=plot_df['playerId'],
                    #hovertemplate = "%{text}",
                    hoverinfo='skip'
                )
            )

        # add arrows on hover
        if clickData is not None:
            # print(clickData)
            area = clickData['points'][0]['curveNumber']
            # print("AREA")
            # print(area)
            x_min = box_x_dict[area][1]
            x_max = box_x_dict[area][2]

            y_min = box_y_dict[area][0]
            y_max = box_y_dict[area][2]

            # filter data to get data for only that box
            pass_df = time_df[time_df['Type'] == 'pass']
            arrow_df = pass_df[pass_df['posX'].between(x_min, x_max)]
            arrow_df = arrow_df[arrow_df['posY'].between(y_min, y_max)]

            x_start_df = arrow_df['posX']
            y_start_df = arrow_df['posY']
            x_end_df = arrow_df['receivedPosX']
            y_end_df = arrow_df['receivedPosY']
            success = arrow_df['isSucceeded']

            ## different colors for successfull and not successfull pass ##
            arrow_color_dict = {
                "true": 'blue',
                "false": 'skyblue'
            }

            arrows = [
                dict(
                    x=x_end,
                    y=y_end,
                    showarrow=True,
                    axref='x', ayref='y',
                    ax=x_start,
                    ay=y_start,
                    arrowhead=3,
                    arrowwidth=1.5,
                    arrowcolor=arrow_color_dict[s]
                ) for x_end, y_end, x_start, y_start, s in zip(x_end_df, y_end_df, x_start_df, y_start_df, success)]
        else:
            arrows = []

        fig.update_layout(
            # paper_bgcolor='rgba(0,0,0,0)',
            legend=dict(x=0.25, y=1),
            legend_orientation="h",
            plot_bgcolor='rgba(0,0,0,0)',
            width=800, height=600,
            annotations=arrows,
            showlegend=True,
            margin=dict(
                l=50,
                r=50,
                b=50,
                t=50,
                pad=4
            ),
        )

        fig.update_yaxes(
            # autorange="reversed",
            visible=False,
        )

        fig.update_xaxes(
            # autorange="reversed",
            visible=False,
        )
        # add data

        fig2 = go.Figure(
            go.Heatmap(
                z=completion_rate,
                x=gridx,
                y=gridy
            )
        )
        return fig, fig2
