import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from dash.dependencies import Input, Output, State, MATCH, ALL
import dash_table

import pandas as pd
import numpy as np
from plotly.subplots import make_subplots
import plotly.graph_objs as go

from .database import database as db

def coach_match_comparison_layout(football_app):

    my_team_name = 'AFCU9-1'
    player_id = "72264"

    internal_parameters = ['exerciseLoad', 'maxVO2', 'runningDistance']
    external_parameters = ['imaAccMid', 'imaAccHigh', 'imaDecMid', 'imaDecHigh',
                        'imaRighMid', 'imaRighHigh', 'imaLeftMid', 'imaLeftHigh']
    ball_parameters = ['touches', 'passes', 'shots', 'tackles']

    possible_team_matches = db.teams_and_matches(my_team_name)

    possible_match_players = db.matches_and_players(possible_team_matches[0])

    layout = html.Div(children=[
        html.Details(children=[
            html.Summary("Match and Parameter Selection"),

            # parameter selection
            html.Div(id='parameter-selection-match-comparison-coach', children=[
                html.Div([
                    html.H6('Internal Parameters', style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='internal-match-comparison-coach',
                        options=[{'label': i, 'value': i}
                                for i in internal_parameters],
                        value=internal_parameters[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%', }),
                html.Div([
                    html.H6('External Parameters', style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='external-match-comparison-coach',
                        options=[{'label': i, 'value': i}
                                for i in external_parameters],
                        value=external_parameters[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%', }),
                html.Div([
                    html.H6('Ball Parameters', style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='ball-match-comparison-coach',
                        options=[{'label': i, 'value': i}
                                for i in ball_parameters],
                        value=ball_parameters[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%', })
            ], style={'padding-top': '10px', 'margin-bottom': '10px'}),

            html.Div(id='match-player-selections-coach', children=[
                html.Div(children=[
                    html.H5("Select Matches", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-comparison-coach-1',
                        options=[{'label': i, 'value': i}
                                for i in possible_team_matches],
                        value=possible_team_matches[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),


                html.Div(children=[
                    html.H5("Select Players", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-comparison-player-select-coach',
                        options=[{'label': i, 'value': i}
                                for i in possible_match_players],
                        value=possible_match_players[0:5],
                        multi=True,
                    )
                ], style={'display': 'inline-block', 'width': '33%'}),

                html.Div(children=[
                    html.H5("Select Matches", style={
                        'textAlign': 'center'}),
                    dcc.Dropdown(
                        id='match-comparison-coach-2',
                        options=[{'label': i, 'value': i}
                                for i in possible_team_matches],
                        value=possible_team_matches[0],
                        multi=True,
                    ),
                ], style={'display': 'inline-block', 'width': '33%'}),
            ]),

        ]),  # end match comparison tab detail
        html.Div(id='match-comparison-chart'),

    ])  # end match comparison tab

    # initiate callbacks
    init_coach_match_comparison_callbacks(football_app)

    return layout



#######################################

################ CALLBACKS #############

########################################

def init_coach_match_comparison_callbacks(football_app):

    # callback for selecting match comparison
    @football_app.callback(
        Output('match-comparison-chart', 'children'),
        [Input('internal-match-comparison-coach', 'value'),
        Input('external-match-comparison-coach', 'value'),
        Input('ball-match-comparison-coach', 'value'),
        Input('match-comparison-player-select-coach', 'value'),
        Input('match-comparison-coach-1', 'value'),
        Input('match-comparison-coach-2', 'value')]
    )
    def update_match_comparison_coach(internal, external, ball, players, matches1, matches2):
        if isinstance(internal, str):
            internal_params = [internal]
        else:
            internal_params = internal

        if isinstance(external, str):
            external_params = [external]
        else:
            external_params = external

        if isinstance(ball, str):
            ball_params = [ball]
        else:
            ball_params = ball

        matches_df1 = db.match_comparison_by_matches_coach(
            matches1, players, internal_params, external_params, ball_params)
        matches_df2 = db.match_comparison_by_matches_coach(
            matches2, players, internal_params, external_params, ball_params)

        children_bar = []
        fig = go.Figure()

        params = internal_params + external_params + ball_params

        for param in params:
            # filter by respective column
            plot_df1 = matches_df1[['playerId', param]]

            # order in descending
            #plot_df1.sort_values(by=param, ascending=False, inplace=True)

            # filter by respective column
            plot_df2 = matches_df2[['playerId', param]]

            # order in descending
            #plot_df2.sort_values(by=param, ascending=False, inplace=True)

            fig = go.Figure()

            # add left match averages matches1
            fig.add_trace(
                go.Bar(x=plot_df1['playerId'], y=plot_df1[param],
                    marker_color='orange', name="Match Selection 1")
            )
            # add right match averages matches2
            fig.add_trace(
                go.Bar(x=plot_df2['playerId'], y=plot_df2[param],
                    marker_color='blue', name="Match Selection 2")
            )

            # update layout
            fig.update_layout(
                yaxis_title=param,
                barmode='group',
                template='plotly_white',
                height=350,
                xaxis=dict(
                    type='category',
                    automargin=True
                ),
                margin=dict(
                    t=10,
                    l=10,
                    r=10
                ),
                font=dict(
                    #family="Courier New, monospace",
                    size=14,
                    color="black"
                )
            )

            # create figure with multiple bar chart
            chart_bar = dcc.Graph(
                id={
                    'type': 'column-table-select',
                    'index': param
                },
                figure=fig
            )

            # append chart to fig list
            children_bar.append(chart_bar)

        return children_bar
